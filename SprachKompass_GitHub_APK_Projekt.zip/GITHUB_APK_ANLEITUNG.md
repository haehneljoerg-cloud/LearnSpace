# SprachKompass – GitHub APK-Build

1. Neues **privates** GitHub-Repository erstellen.
2. Alle Dateien dieses Ordners (einschließlich `.github/workflows/android-apk.yml`) in die **oberste Ebene** des Repositorys hochladen. Die `.github`-Ordnerstruktur muss erhalten bleiben.
3. `Actions` öffnen → `SprachKompass - Android APK` → `Run workflow` oder einen Commit auf `main` ausführen.
4. Beim erfolgreichen Run unter `Artifacts` → `SprachKompass-Android-Debug-APK` herunterladen.
5. ZIP entpacken: Die Datei `app-debug.apk` ist eine Debug-Version für private Funktionstests, nicht für den Play Store.

**Wichtig:** Nur die Browser-App ist in der APK. Der Python-Server für Synchronisation und KI muss gesondert via HTTPS laufen. Die APK hat die interne Origin `https://localhost`; daher muss beim Server die CORS-Allowlist auch diese Origin erlauben. Die relative URL `./api/generate` für die Foto-KI läuft im APK-Kontext nicht zum externen Server. Vor Live-Nutzung ist hierfür eine konfigurierbare vollständige API-URL erforderlich. APK-Installationen werden nicht möglich, wenn das Android-Gerät sie durch Sicherheitseinstellungen oder eine Verwaltungsrichtlinie verbietet. Ein Debug-APK verwendet einen Testschlüssel und ist nicht für Veröffentlichung bestimmt. Nicht die `.env` mit Geheimnissen zu GitHub hochladen.
