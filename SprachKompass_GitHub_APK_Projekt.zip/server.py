#!/usr/bin/env python3
"""SprachKompass: local PWA server, optional authenticated AI photo extraction.

Python 3.10+ standard library only. AI credentials are server-side environment
variables, never inserted into web pages or app bundles.
"""
import base64
import hmac
import json
import os
import re
import sys
import time
import urllib.error
import urllib.request
from collections import defaultdict, deque
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse
from sync_api import handle as sync_handle, MAX_SYNC_BODY

ROOT = Path(__file__).resolve().parent
MAX_REQUEST_BYTES = 24 * 1024 * 1024
MAX_IMAGES = 6
RATE_LIMIT = 12  # Per IP per hour, additional provider caps recommended for production
recent = defaultdict(deque)

SYSTEM_PROMPT = """Du entwickelst Lernmaterial für eine private schulische Sprachlern-App.
Du erhältst Bilder von fremdsprachlichen Lehrbuchseiten. Lies nur ECHT erkennbare
Informationen. Bei unleserlichen Wörtern NICHT raten, sondern weglassen.
Das Sprach- und Kapitelziel steht in der Anfrage. Der Nutzer kann die Buchseiten
(von/bis) vorgeben. Nutze konkrete Seitennummern nur, wenn sie im Bild oder
in der Anfrage hinreichend belegt sind. Falls eine Seitenstrecke angegeben wird
und unklar ist, auf welcher einzelnen Seite ein Inhalt steht, verwende für diesen
Inhalt den ganzen angegebenen Bereich. Erfinde niemals genaue Seitennummern.
 Der Modus lautet:
- auto: Erkenne selbst, ob die Seite Vokabular, Grammatik oder beides enthält.
  Erzeuge passende Vokabeln, verständliche Grammatikmerkblätter und eigene Übungen.
- both: Vokabeln und Grammatik sowie passende Übungen.
- vocab: nur isolierte Wörter/Ausdrücke und korrekte deutsche Entsprechungen.
- grammar: Grammatikregeln und dazu eigene Aufgaben, möglichst Dropdown und Hörtext.
- exercises: Übungen auf Basis erkannter Themen, keine Buchaufgaben abschreiben.
Wenn ein Schwerpunkt genannt ist, priorisiere diesen, ohne unbelegte Dinge zu erfinden.

Liefer EXAKT ein JSON-Objekt mit diesen 4 Feldern (auch leere Listen angeben):
{
 "detection": {"category":"Vokabular|Grammatik|Grammatik + Vokabular|Übungen|Nicht eindeutig",
               "topics":["knappe konkrete Themen, z. B. Simple Past, Present Perfect"]},
 "vocabulary": [{"source":"Wort/Ausdruck in der Fremdsprache", "target":"Deutsch",
                 "example":"NEU formulierter kurzer Beispielsatz", "unit":"Kapitel",
                 "pageStart":null, "pageEnd":null}],
 "grammar": [{"title":"konkreter Grammatikthemenname",
              "content":"übersichtliche eigenständige Regeln, Bildung, Verwendung, Signalwörter, häufige Fehler",
              "examples":["ORIGINALER kurzer korrekter Beispielsatz mit deutscher Erklärung"],
              "unit":"Kapitel", "pageStart":null, "pageEnd":null}],
 "exercises": [{"title":"Aufgabenname", "type":"dropdown|text|listening",
                "question":"selbst erfundener Satz mit ___ als Lücke oder Verständnisfrage",
                "answer":"korrekte Antwort (mehrere Lücken: ;; getrennt)",
                "answers":["optionale Antworten je Lücke"],
                "options":["falsche Möglichkeit", "richtige Möglichkeit", "weitere falsche Möglichkeit"],
                "spokenText":"nur Hörübung: selbst erfundener kurzer Hörtext in Zielsprache",
                "explanation":"knappe Erklärung", "unit":"Kapitel",
                "pageStart":null, "pageEnd":null}]
}

KRITISCHES QUALITÄTSZIEL: Grammatikregeln müssen sachlich korrekt sein, keine
fehlerhaften Signalwort-Automatismen. Bei Vergleichen wie Simple Past / Present
Perfect biete mehrere neue, abwechslungsreiche Dropdown-Lückentexte (type=dropdown).
Bei Dropdownübungen muss question mind. ein '___' enthalten, die richtige Antwort
in options stehen, und die Lückenanzahl der answers-Liste entsprechen.
Bei listening: spokenText ist eigener Text von 1–3 kurzen Sätzen,
question ist eine Verständnisfrage, options enthält die korrekte Antwort.
Mindestens eine Hörübung, wenn der Stoff sinnvoll Sprachverständnis ermöglicht.

Urheberrecht: Beziehe NUR Unterrichtsthemen und einzelne nachweislich lesbare
Vokabelpaare aus Fotos. Kopiere KEINE Buchbeispielsätze, Aufgabenformulierungen,
Dialoge, Erzählungen, Arbeitsblattstrukturen oder längeren geschützten Textpassagen.
Beispielsätze, Geschichten, Hörtexte und Übungsfragen müssen eigenständige neue
Kreationen sein – keine bloß oberflächlichen Umformulierungen. Übernimm KEINE
personenbezogenen Informationen von abgebildeten Schülern. Keine Bilder oder
Buchpassagen in die Ausgabe einbetten. Für nicht belegte Vokabelübersetzungen
keine Annahmen treffen. Verwende keine Informationen aus dem Buch, die sich
nicht aus den Bildern ablesen lassen. Begrenze Übungen auf rund 5–9 und
Merkblätter auf 1–3 pro eingescanntem Thema. JSON ohne Markdown.
"""


def json_response(handler, status, obj):
    body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
    handler.send_response(status)
    handler.send_header('Content-Type', 'application/json; charset=utf-8')
    handler.send_header('Content-Length', str(len(body)))
    handler.send_header('Cache-Control', 'no-store')
    handler.send_header('X-Content-Type-Options', 'nosniff')
    handler.end_headers()
    handler.wfile.write(body)


def strip_json(response_data):
    parts = []
    if isinstance(response_data.get('output_text'), str):
        parts.append(response_data['output_text'])
    for item in response_data.get('output', []):
        for content in item.get('content', []):
            if content.get('type') == 'output_text':
                parts.append(content.get('text', ''))
    content = '\n'.join(parts).strip()
    if content.startswith('```'):
        content = re.sub(r'^```(?:json)?\s*|\s*```$', '', content).strip()
    return json.loads(content)


def sanitize_result(obj, unit, page_start=None, page_end=None):
    if not isinstance(obj, dict):
        raise ValueError('Antwort enthält kein JSON-Objekt')
    det = obj.get('detection', {})
    if not isinstance(det, dict):
        det = {}
    topics = det.get('topics', [])
    if not isinstance(topics, list):
        topics = []
    cleaned = {'detection': {
        'category': str(det.get('category', 'Nicht eindeutig'))[:90],
        'topics': [str(x)[:75] for x in topics[:12] if isinstance(x, str)],
    }}
    for key, limit, fields in [
        ('vocabulary', 400, ['source', 'target', 'example', 'unit']),
        ('grammar', 10, ['title', 'content', 'unit']),
        ('exercises', 30, ['title', 'question', 'answer', 'explanation', 'unit', 'spokenText', 'type']),
    ]:
        items = obj.get(key, [])
        if not isinstance(items, list):
            items = []
        results = []
        for item in items[:limit]:
            if not isinstance(item, dict):
                continue
            o = {field: str(item.get(field, '') or '')[:9000] for field in fields}
            o['unit'] = o['unit'] or unit
            def valid_page(v):
                try:
                    number = int(v)
                    return number if 0 < number < 10000 else None
                except (TypeError, ValueError):
                    return None
            requested_a, requested_b = valid_page(page_start), valid_page(page_end)
            own_a, own_b = valid_page(item.get('pageStart')), valid_page(item.get('pageEnd'))
            # A user-supplied range is guaranteed provenance only for the batch.
            # The model may identify an individual page within it, but do not
            # trust an out-of-range claim over the user-supplied boundaries.
            if requested_a and requested_b and requested_a > requested_b:
                raise ValueError('Startseite liegt nach Endseite')
            within_requested = lambda n: (not requested_a or n >= requested_a) and (not requested_b or n <= requested_b)
            if own_a and within_requested(own_a) and (not own_b or (own_b >= own_a and within_requested(own_b))):
                first, last = own_a, own_b or own_a
            elif own_b and within_requested(own_b):
                first = last = own_b
            else:
                first = requested_a or requested_b
                last = requested_b or requested_a
            o['pageStart'] = first
            o['pageEnd'] = last
            if key == 'grammar':
                ex = item.get('examples', [])
                o['examples'] = [str(x)[:900] for x in ex[:20]] if isinstance(ex, list) else []
                if o['title'] and o['content']:
                    results.append(o)
            elif key == 'exercises':
                o['type'] = o['type'] if o['type'] in ('dropdown', 'text', 'listening') else 'text'
                op = item.get('options', [])
                o['options'] = [str(x).strip()[:150] for x in op[:12] if str(x).strip()] if isinstance(op, list) else []
                ans = item.get('answers', [])
                o['answers'] = ([str(x).strip()[:180] for x in ans[:12] if str(x).strip()]
                                if isinstance(ans, list) else [])
                if not o['answer'] and o['answers']:
                    o['answer'] = ' ;; '.join(o['answers'])
                if not o['answers'] and o['answer']:
                    o['answers'] = [x.strip() for x in o['answer'].split(';;')]
                blanks = o['question'].count('___')
                if o['type'] != 'listening' and blanks and len(o['answers']) != blanks:
                    continue
                if o['type'] == 'listening' and not o['spokenText']:
                    continue
                if o['type'] == 'dropdown' and (not o['options'] or any(a.split('|')[0] not in o['options'] for a in o['answers'])):
                    continue
                if o['question'] and o['answer']:
                    results.append(o)
            elif o['source'] and o['target']:
                results.append(o)
        cleaned[key] = results
    return cleaned


def ask_openai(payload):
    api_key = os.environ.get('OPENAI_API_KEY', '').strip()
    if not api_key:
        raise RuntimeError('OPENAI_API_KEY ist auf dem Server nicht gesetzt.')
    lang = str(payload.get('language') or 'Englisch')[:45]
    unit = str(payload.get('unit') or 'Ohne Kapitel')[:70]
    mode = payload.get('task', 'auto')
    if mode not in ('auto', 'both', 'vocab', 'grammar', 'exercises'):
        raise ValueError('Unbekannter Aufgabentyp')
    focus = str(payload.get('focus') or '')[:120]
    start = payload.get('pageStart') or None
    end = payload.get('pageEnd') or None
    if start and end and int(start) > int(end):
        raise ValueError('Die Startseite liegt nach der Endseite')
    images = payload.get('images', [])
    if not isinstance(images, list) or not 1 <= len(images) <= MAX_IMAGES:
        raise ValueError('Es werden 1 bis 6 Bilder benötigt.')
    user_content = [{
        'type': 'input_text',
        'text': f'Fremdsprache: {lang}. Kapitel/Unit: {unit}. Bearbeitungsmodus: {mode}. '
                f'Themenwunsch: {focus or "Bitte selbst erkennen"}. '
                'Erstelle kontrollierbare Vorschläge als JSON. Verwende eigenständige Übungstexte.'
    }]
    for img in images:
        if not isinstance(img, str) or not re.match(r'^data:image/(jpeg|png|webp);base64,', img):
            raise ValueError('Ungültiges Bildformat')
        data = img.split(',', 1)[1]
        # Validate encoding and approximate size. Max 5 MB decoded per image.
        if len(data) > 7_000_000:
            raise ValueError('Bild ist nach der Komprimierung zu groß')
        try:
            raw = base64.b64decode(data, validate=True)
        except Exception as exc:
            raise ValueError('Ungültige Bildkodierung') from exc
        if len(raw) > 5_250_000:
            raise ValueError('Bild ist zu groß')
        user_content.append({'type': 'input_image', 'image_url': img, 'detail': 'high'})

    request_body = json.dumps({
        'model': os.environ.get('OPENAI_MODEL', 'gpt-4.1-mini'),
        'instructions': SYSTEM_PROMPT,
        'input': [{'role': 'user', 'content': user_content}],
        'text': {'format': {'type': 'json_object'}},
        'max_output_tokens': 6500
    }, ensure_ascii=False).encode('utf-8')
    req = urllib.request.Request(
        'https://api.openai.com/v1/responses',
        data=request_body,
        headers={'Authorization': 'Bearer ' + api_key,
                 'Content-Type': 'application/json',
                 'User-Agent': 'SprachKompass-Prototype/1.0'},
        method='POST'
    )
    try:
        with urllib.request.urlopen(req, timeout=95) as response:
            response_data = json.loads(response.read())
    except urllib.error.HTTPError as exc:
        if exc.code in (401, 403):
            raise RuntimeError('Der hinterlegte KI-API-Schlüssel ist ungültig oder nicht berechtigt.') from exc
        if exc.code == 429:
            raise RuntimeError('KI-Anfragenlimit erreicht oder API-Guthaben fehlt.') from exc
        raise RuntimeError('KI-Anfrage vom Anbieter abgelehnt (HTTP ' + str(exc.code) + ').') from exc
    except urllib.error.URLError as exc:
        raise RuntimeError('KI-Anbieter nicht erreichbar.') from exc
    try:
        return sanitize_result(strip_json(response_data), unit, start, end)
    except (ValueError, KeyError, TypeError) as exc:
        raise RuntimeError('Die KI-Antwort konnte nicht zuverlässig ausgewertet werden. Erneut versuchen.') from exc


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def allowed_origin(self):
        origin = self.headers.get('Origin', '')
        if not origin:
            return True
        host = self.headers.get('Host', '')
        own = {'http://' + host, 'https://' + host}
        configured = {x.strip().rstrip('/') for x in os.environ.get('APP_ORIGINS', '').split(',') if x.strip()}
        return origin in own or origin in configured

    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        if urlparse(self.path).path.startswith('/api/'):
            origin = self.headers.get('Origin', '')
            if origin and self.allowed_origin():
                self.send_header('Access-Control-Allow-Origin', origin)
                self.send_header('Vary', 'Origin')
        super().end_headers()

    def do_OPTIONS(self):
        if not urlparse(self.path).path.startswith('/api/') or not self.allowed_origin():
            self.send_error(403)
            return
        self.send_response(204)
        self.send_header('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Authorization,Content-Type,X-Sync-Setup,X-Admin-Password')
        self.send_header('Access-Control-Max-Age', '600')
        self.end_headers()

    def read_json(self, max_bytes):
        try:
            size = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            size = 0
        if not 1 <= size <= max_bytes:
            raise ValueError('Anfrage ist leer oder zu groß.')
        value = json.loads(self.rfile.read(size))
        if not isinstance(value, dict):
            raise ValueError('JSON-Objekt erforderlich.')
        return value

    def do_GET(self):
        p = urlparse(self.path).path
        if p.startswith('/api/') and not self.allowed_origin():
            return json_response(self, 403, {'error': 'App-Ursprung ist nicht freigegeben.'})
        if p == '/api/health':
            return json_response(self, 200, {
                'aiConfigured': bool(os.environ.get('OPENAI_API_KEY') and os.environ.get('ADMIN_PASSWORD')),
                'syncConfigured': len(os.environ.get('SYNC_SETUP_SECRET', '')) >= 16
            })
        if p == '/api/sync/content':
            return self.sync_route('GET', p, {})
        # Never serve server source, data files, credentials, hidden files, or
        # arbitrary paths. The static public surface is intentionally tiny.
        permitted = p in ('/', '/index.html', '/app.js', '/manifest.webmanifest', '/sw.js') or (
            p.startswith('/icons/') and p.endswith('.png') and p.count('/') == 2)
        if not permitted:
            return self.send_error(404)
        return super().do_GET()

    def do_POST(self):
        return self.route_write('POST')

    def do_PUT(self):
        return self.route_write('PUT')

    def do_PATCH(self):
        return self.route_write('PATCH')

    def sync_route(self, method, path, payload):
        try:
            status, result = sync_handle(method, path, self.headers, payload, self.client_address[0])
            return json_response(self, status, result)
        except (ValueError, json.JSONDecodeError) as exc:
            return json_response(self, 400, {'error': str(exc)[:200]})
        except Exception as exc:
            print('Sync backend error:', type(exc).__name__, file=sys.stderr)
            return json_response(self, 503, {'error': 'Synchronisationsserver nicht verfügbar. Konfiguration und Speicher prüfen.'})

    def route_write(self, method):
        path = urlparse(self.path).path
        if not self.allowed_origin():
            return json_response(self, 403, {'error': 'App-Ursprung ist nicht freigegeben.'})
        if path.startswith('/api/sync/'):
            if path not in ('/api/sync/create','/api/sync/join','/api/sync/invite',
                            '/api/sync/revoke-children','/api/sync/content','/api/sync/progress'):
                return json_response(self, 404, {'error': 'Unbekannter API-Pfad'})
            try:
                payload = self.read_json(MAX_SYNC_BODY)
            except (ValueError, json.JSONDecodeError) as exc:
                return json_response(self, 400, {'error': str(exc)[:180]})
            return self.sync_route(method, path, payload)
        if path != '/api/generate' or method != 'POST':
            return json_response(self, 404, {'error': 'Unbekannter API-Pfad'})
        password = os.environ.get('ADMIN_PASSWORD', '')
        if not password or not hmac.compare_digest(self.headers.get('X-Admin-Password', ''), password):
            return json_response(self, 401, {'error': 'Server-Passwort fehlt oder ist falsch.'})
        if not os.environ.get('OPENAI_API_KEY'):
            return json_response(self, 503, {'error': 'KI ist nicht eingerichtet: OPENAI_API_KEY fehlt.'})
        ip = self.client_address[0]
        q = recent[ip]
        while q and q[0] < time.monotonic() - 3600:
            q.popleft()
        if len(q) >= RATE_LIMIT:
            return json_response(self, 429, {'error': 'Zu viele KI-Anfragen. Bitte später erneut versuchen.'})
        try:
            payload = self.read_json(MAX_REQUEST_BYTES)
            q.append(time.monotonic())
            output = ask_openai(payload)
            return json_response(self, 200, output)
        except (ValueError, json.JSONDecodeError) as exc:
            return json_response(self, 400, {'error': str(exc)[:250]})
        except Exception as exc:
            message = str(exc) if isinstance(exc, RuntimeError) else 'Interner Fehler bei der KI-Verarbeitung.'
            return json_response(self, 502, {'error': message[:250]})


if __name__ == '__main__':
    port = int(os.environ.get('PORT', '8765'))
    bind = os.environ.get('BIND_HOST', '127.0.0.1')
    srv = ThreadingHTTPServer((bind, port), Handler)
    print(f'SprachKompass gestartet: http://{bind}:{port}')
    print('Synchronisierung: ' + ('konfiguriert' if len(os.environ.get('SYNC_SETUP_SECRET', '')) >= 16 else 'inaktiv – SYNC_SETUP_SECRET fehlt'))
    print('Für Synchronisierung zwischen Geräten: HTTPS, persistentes SYNC_DB_PATH und APP_ORIGINS prüfen.')
    print('KI-Analyse: ' + ('konfiguriert' if (os.environ.get('OPENAI_API_KEY') and os.environ.get('ADMIN_PASSWORD')) else 'inaktiv – Offline-Lernen und manueller Import verfügbar'))
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print('\nServer beendet')
    finally:
        srv.server_close()
