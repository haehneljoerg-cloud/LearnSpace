# SprachKompass 0.5 – Familie synchronisieren

Neue Version mit Eltern-Cloud-Freigabe, 15 Minuten gültigem Verbindungscode und offlinefähigem Kindergerät. **Die Synchronisation benötigt einen laufenden HTTPS-Server**; die reine HTML-Demo und das statische PWA-Paket sind allein noch kein Live-Cloud-Dienst.

## Ablauf

1. Server nach Anleitung unten betreiben. HTTPS und persistente Festplatte sind Voraussetzung für die Nutzung über das Internet.
2. Auf dem **Eltern-Gerät**: Eltern-PIN eingeben, Reiter **☁️ Synchronisation**, `https://...`-Serveradresse sowie das `SYNC_SETUP_SECRET` eintragen. **Familie anlegen und Inhalte freigeben** wählen. Die Familien-Verbindung wird lokal gespeichert.
3. Auf **Kindgerät**: gleiche App-Webadresse öffnen/installieren, bei Bedarf Sprache einmalig wählen. Oben auf **☁️ Verbinden** tippen. Auf dem Elterngerät im Sync-Reiter **＋ Kindgerät verbinden** wählen. Den **15 Minuten** gültigen Einmalcode und Serveradresse auf dem Kindgerät eingeben. Danach synchronisiert es die freigegebenen Inhalte.
4. Weitere Buchseiten und Übungen wie gewohnt im Elternbereich bearbeiten, kontrollieren und anschließend **✓ Geprüfte Inhalte freigeben** drücken. Das Kindgerät lädt sie bei sichtbarer Online-App beim Start, bei Rückkehr aus dem Hintergrund sowie ungefähr jede Minute herunter. Es behält alle Inhalte lokal, sodass Lernen und PDFs offline funktionieren.
5. Wenn das Kind Wörter oder Übungen mit ⭐ versieht, werden **nur diese Merkmarkierungen** bei erfolgreicher Verbindung an den Server übertragen. Im Eltern-Sync-Reiter zeigt **Aktuellen Cloudstand prüfen** die Anzahl gemerkter Wörter/Übungen. Das Kind kann keine Vokabellisten/Merkblätter/Übungen auf dem Server ändern. Der Eltern-PIN ist nur eine lokale Bedienungssperre, der eigentliche Serverzugriff wird mit getrennten kryptografisch zufälligen Berechtigungstokens abgesichert.

## Server – lokal starten (Python 3.10+, Standardbibliothek)

Linux/macOS:

```bash
export SYNC_SETUP_SECRET='HIER-EIN-LANGES-ZUFAELLIGES-PASSWORT-MIND-16-ZEICHEN'
export SYNC_DB_PATH='/var/lib/sprachkompass/family.sqlite3'
export APP_ORIGINS='https://deine-app-domain.example'
export BIND_HOST='127.0.0.1'
export PORT='8765'
python server.py
```

Windows PowerShell:

```powershell
$env:SYNC_SETUP_SECRET='EIN-LANGES-ZUFAELLIGES-SERVERPASSWORT'
$env:SYNC_DB_PATH="$env:USERPROFILE\sprachkompass-family.sqlite3"
python server.py
```

Test im gleichen Rechner: `http://127.0.0.1:8765`. Für Android-Telefone ist dieser Loopback-Host **nicht** von anderen Geräten erreichbar. Für echte Gerätesynchronisierung muss der Python-Webserver über eine HTTPS-geschützte Domain veröffentlicht werden, z. B. mit einem HTTPS-Reverse-Proxy und einem Host mit dauerhaftem Dateispeicher. `BIND_HOST=0.0.0.0` nur in einer passend abgesicherten Netzwerkumgebung verwenden; nicht ohne TLS/Firewall direkt ins Internet exponieren. Ein einfaches statisches Hosting (Netlify Drop) kann die Python-API oder SQLite-Datenbank **nicht** betreiben. Für App und API auf unterschiedlichen Domains muss `APP_ORIGINS` die **exakte App-Origin** enthalten (HTTPS, ohne abschließenden Schrägstrich). Der KI-Foto-Upload der alten Version ruft derzeit `./api/generate` auf und funktioniert daher nur mit derselben API-Origin oder nach entsprechender Konfiguration.

Für einen dauerhaft laufenden Server empfehlenswert: HTTPS mit gültigem Zertifikat, nicht öffentlich zugängliche SQLite-Datenbank an `SYNC_DB_PATH`, regelmäßige Backups der Datenbank, Prozessüberwachung, IP-Ratelimits am Reverse Proxy, feste App-Origin, regelmäßige Sicherheitsupdates. Dieser Code ist ein getesteter Prototyp, **kein extern sicherheitsauditierter Produktivdienst**.

### Trennung, Datensicherheit, Grenzen

- **Kinderrechte:** Kindertoken dürfen veröffentlichte Lerninhalte lesen und **ausschließlich ihre Merkkennzeichnungen** übertragen. Der serverseitige Materialupload erfordert das Eltern-Token. Passwörter und Tokens werden nicht mit dem veröffentlichten Lernmaterial synchronisiert.
- **Einmalcodes** sind 10 Zeichen lang, nur einmal verwendbar und 15 Minuten gültig. **Kindgeräte sperren** widerruft alle Kindertokens serverseitig; bereits offline gespeicherte Lerninhalte lassen sich dadurch nicht nachträglich von den Geräten löschen.
- **Bei Verlust des Eltern-Tokens** (z. B. gelöschte Browserdaten) kann man sich nicht per PIN beim Server wieder anmelden. Ein neuer Familienbereich muss angelegt und Kindgeräte neu gekoppelt werden. Passwort, Datenbank und Browserprofile sichern. JSON-Backups sichern Lerninhalte, absichtlich **keine** Geheimtokens.
- Das Programm ist derzeit für **eine Familie mit einem gemeinsamen Kinder-Lernfortschritt** gedacht. Mehrere Kinderprofile, automatische Konfliktzusammenführung und Ende-zu-Ende-Verschlüsselung sind noch nicht implementiert.
- **Freigabe bewusst manuell:** Geprüfte Buchinhalte werden erst nach Klick auf **Freigeben** hochgeladen; das reine Bearbeiten von Vokabeln schickt nichts an den Server. Als JSON-Backup sind Lerninhalte lokal exportierbar.
- **Offline-Merklisten:** Änderungen offline bleiben lokal gespeichert und werden erst wieder nach dem nächsten Online-Abgleich synchronisiert. Bei Verbindungsproblemen bleibt die Lernfunktion erhalten. Während die App geschlossen ist, gibt es keine garantierte Hintergrundübertragung.
- **Datenschutz/Copyright:** Keine echten Schülernamen, Gesichter, Noten oder sensiblen Kinderdaten hochladen. Bilder werden nicht an die Synchronisations-API übermittelt; nur die zuvor freigegebenen Lerninhalte. Urheberrechtliche Verwertungsrechte für Lehrbuchscans und Veröffentlichungen müssen trotzdem geprüft werden.

## Dateien

- `index.html`, `app.js`, `sw.js`, `manifest.webmanifest`, `icons/`: offlinefähige PWA, Eltern- und Kinderfunktionen
- `server.py`, `sync_api.py`: HTTPS-seitig zu betreibender API-Server, SQLite-Datenspeicher außerhalb der Webwurzel
- `.env.example`: Beispielkonfiguration ohne echte Passwörter

Alle bisherigen Funktionen aus Version 0.4 bleiben erhalten: Einmal-Sprachwahl, Unit-/Seitenfilter, Karteikarten, Merkliste, editierbare Inhalte, eigene KI-Übungen, Lücken-Dropdown, Hörtexte, Merkblattdruck und getrennte Aufgaben-/Lösungs-PDFs. Die KI-Fotoerkennung braucht weiter einen separaten OpenAI-API-Schlüssel; die Familien-Synchronisierung benötigt **keine KI-API**.

## Beispiel: Einmalige Veröffentlichung mit Docker und HTTPS

Für einen eigenen Server (z. B. einen kleinen VPS) mit installiertem Docker Compose und einer Domain liegen `Dockerfile`, `compose.yaml` und `Caddyfile` bei. Die Domain muss per DNS auf den Server zeigen, und die Ports 80/443 müssen erreichbar sein. In diesem Paket werden **App und API unter derselben Adresse** bereitgestellt – es ist dann kein gesondertes statisches Netlify-Hosting notwendig.

Erstelle im Projektverzeichnis eine private Datei `.env` (nicht veröffentlichen):

```dotenv
APP_DOMAIN=lernen.eigene-domain.de
SYNC_SETUP_SECRET=EIN-SEHR-LANGES-ZUFAELLIGES-PASSWORT-32-ZEICHEN
```

Dann `docker compose up -d --build` ausführen und im Browser `https://lernen.eigene-domain.de` öffnen. Der Reverse Proxy Caddy kann bei korrekt erreichbarer Domain HTTPS-Zertifikate verwalten. Daten liegen im persistenten lokalen Ordner `private-data/`, der nicht in das Web ausgeliefert wird. **Sicherung des Ordners regelmäßig auf ein anderes Medium durchführen.** Die beispielhafte Docker-Installation und ein öffentlicher Internetbetrieb sind in diesem Chat nicht live geprüft; die Backend-/Browser-Funktionstests liefen lokal. Vor öffentlicher Nutzung außerdem die Freigabe- und Löschkonzepte, Datenschutzerklärung, Hosting-Datenschutz und Schutz vor missbräuchlichen Registrierungen prüfen.
