# SprachKompass 0.6 – Offline-Lernpakete

Kein API-Schlüssel, kein KI-Server, kein Familien-Synchronisationsserver.

## Nutzung
1. Schulbuchseiten im Chat hochladen und Sprache, Unit und Seiten nennen.
2. Von ChatGPT eine `lerninhalte.json` mit Arrays `vocab`, `notes`, `exercises` erzeugen lassen.
3. In der App **Eltern → Daten → Lernpaket ergänzen** wählen. Das Paket wird geprüft und nach Bestätigung ergänzt.
4. Bestehende Merkliste und PIN bleiben erhalten. Ein Backup wird vor dem Import heruntergeladen.
5. Die App kann alternativ mit aktualisiertem Inhalt neu gebaut werden, aber für neue Lernpakete ist kein APK-Update nötig.

### Datenfelder
Jeder Eintrag benötigt `language` (z. B. `Englisch`), `unit` (z. B. `Unit 3`) und optional `pageStart`, `pageEnd`.
Vokabeln: `source`, `target`, optional `example`.
Merkblätter: `title`, `content`, optional `examples` als Array.
Übungen: `title`, `question`, `answer`, `type` (`dropdown`, `text`, `listening`), optional `options` als Array, `spokenText`, `explanation`.

Für Dropdown-Aufgaben muss `question` die Lücke `___` enthalten und `options` mindestens zwei Antworten. Mehrere Lücken: Antworten mit `;;` trennen.

## Hinweis
Die lokale App speichert Daten im WebView-Speicher. Beim Update derselben Android-App-ID bleiben sie normalerweise erhalten, aber das ist keine Garantie. Vor Updates ein Backup exportieren. Deinstallation oder Löschen der App-Daten kann Lernfortschritt löschen.

Die Synchronisation zwischen Geräten ist in v0.6 deaktiviert. Austausch erfolgt über JSON-Export/Import. Der separate vollständige Backup-Import ersetzt weiterhin Daten; für Updates den neuen Lernpaket-Import verwenden.

Die Eltern-PIN ist eine einfache Bedienungssperre, keine sichere Trennung gegen technisch versierte Nutzer.
