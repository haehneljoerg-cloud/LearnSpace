'use strict';
(() => {
 const $ = (id) => document.getElementById(id);
 const esc = (s='') => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const norm = s => String(s??'').toLocaleLowerCase('de').normalize('NFKC').trim().replace(/\s+/g,' ');
 const uid = () => (typeof crypto!=='undefined' && crypto.randomUUID ? crypto.randomUUID() : 'id-'+Date.now()+'-'+Math.random().toString(36).slice(2));
 const now = () => new Date().toISOString();
 const SAMPLE = {
  vocab:[
   {id:'demo1',pageStart:12,pageEnd:12,source:'to discover',target:'entdecken',language:'Englisch',unit:'Unit 1',example:'We discovered a new path.',star:false,demo:true},
   {id:'demo2',pageStart:12,pageEnd:12,source:'a journey',target:'eine Reise',language:'Englisch',unit:'Unit 1',example:'It was a long journey.',star:false,demo:true},
   {id:'demo3',pageStart:13,pageEnd:13,source:'although',target:'obwohl',language:'Englisch',unit:'Unit 1',example:'Although it rained, we went out.',star:false,demo:true},
   {id:'demo4',pageStart:22,pageEnd:22,source:'improve',target:'verbessern',language:'Englisch',unit:'Unit 2',example:'I want to improve my English.',star:false,demo:true},
   {id:'demo5',pageStart:23,pageEnd:23,source:'carefully',target:'vorsichtig / sorgfältig',language:'Englisch',unit:'Unit 2',example:'Read the question carefully.',star:false,demo:true},
   {id:'demo6',pageStart:8,pageEnd:8,source:'la ventana',target:'das Fenster',language:'Spanisch',unit:'Lección 1',example:'Abre la ventana.',star:false,demo:true},
   {id:'demo7',pageStart:9,pageEnd:9,source:'aprender',target:'lernen',language:'Spanisch',unit:'Lección 1',example:'Quiero aprender español.',star:false,demo:true}
  ],
  notes:[{id:'demo-note',pageStart:22,pageEnd:23,language:'Englisch',unit:'Unit 2',title:'Modal verbs: must / have to',content:'Mit must drückst du eine Verpflichtung aus.\nMit mustn’t drückst du ein Verbot aus.\nMit don’t have to sagst du, dass etwas nicht notwendig ist.\n\nAchtung: mustn’t und don’t have to haben verschiedene Bedeutungen!',examples:['You must wear a seat belt. – Du musst einen Sicherheitsgurt tragen.','You mustn’t touch that. – Du darfst das nicht anfassen.','You don’t have to come early. – Du musst nicht früh kommen.'],demo:true}],
  exercises:[{id:'demo-ex1',pageStart:22,pageEnd:22,language:'Englisch',unit:'Unit 2',title:'Modal verbs',question:'You ___ wear a helmet on your bike. (Verpflichtung)',answer:'must',explanation:'must beschreibt eine Verpflichtung.',demo:true},{id:'demo-ex2',pageStart:23,pageEnd:23,language:'Englisch',unit:'Unit 2',title:'Modal verbs',question:'You ___ park here. It is forbidden.',answer:'mustn’t',options:['mustn’t','don’t have to','may'],type:'dropdown',explanation:'mustn’t = nicht dürfen, Verbot.',demo:true},{id:'demo-ex3',pageStart:41,pageEnd:41,language:'Englisch',unit:'Unit 3',title:'Simple Past oder Present Perfect',question:'I ___ in Berlin last summer.',answer:'stayed',options:['stayed','have stayed','stay'],type:'dropdown',explanation:'Last summer ist ein abgeschlossener Zeitpunkt in der Vergangenheit: Simple Past.',demo:true},{id:'demo-ex4',pageStart:42,pageEnd:42,language:'Englisch',unit:'Unit 3',title:'Hörverständnis',type:'listening',spokenText:'Yesterday, Mia found a blue notebook beside the playground. She took it to her teacher.',question:'Was hat Mia gefunden?',answer:'a blue notebook',options:['a blue notebook','a red backpack','a green jacket'],explanation:'Mia fand ein blaues Notizbuch.',demo:true}],
  meta:{createdAt:now()}
 };
 const STORAGE_KEY='sprachkompass-local-v1';
 const clone=v=>JSON.parse(JSON.stringify(v));
 let storageOK=true;
 let data;
 try {const raw=localStorage.getItem(STORAGE_KEY);data=raw?JSON.parse(raw):clone(SAMPLE)} catch(e){data=clone(SAMPLE);storageOK=false}
 if(!data||!Array.isArray(data.vocab)||!Array.isArray(data.notes)||!Array.isArray(data.exercises))data=clone(SAMPLE);
 data.meta=data.meta||{};
 let current='home',cardIdx=0,cardFlipped=false,cardSubset=[],cardSavedOnly=false,cardDir='toDe',adminUnlocked=false,aiDraft=null,toastTimer;
 let savedPage=0,notePage=0,exercisePage=0,noteSlides=[],exerciseSavedOnly=false;
 const LANGS=['Englisch','Spanisch','Französisch','Italienisch','Latein'];
 const activeLanguage=()=>data.meta.studyLanguage||'';
 const scope=data.meta.studyScope&&typeof data.meta.studyScope==='object'?data.meta.studyScope:{unit:'',from:'',to:''};
 const pageNum=x=>{const n=Number(x);return Number.isInteger(n)&&n>0?n:null};
 const pageBounds=item=>{const x=pageNum(item.pageStart||item.page||item.pageNumber),y=pageNum(item.pageEnd);if(!x&&!y)return null;return [Math.min(x||y,y||x),Math.max(x||y,y||x)]};
 const pageLabel=item=>{const b=pageBounds(item);return b?'S. '+b[0]+(b[1]!==b[0]?'–'+b[1]:''):'Seite nicht erfasst'};
 function withinScope(item){if(item.language!==activeLanguage())return false;if(scope.unit&&item.unit!==scope.unit)return false;
   if(scope.from||scope.to){const b=pageBounds(item);if(!b)return false;if(scope.from&&b[1]<Number(scope.from))return false;if(scope.to&&b[0]>Number(scope.to))return false;}return true}
 const allContent=()=>[...data.vocab,...data.notes,...data.exercises];
 function syncScope(){const options=choices(allContent().filter(x=>x.language===activeLanguage()).map(x=>x.unit));if(scope.unit&&!options.includes(scope.unit))scope.unit='';
  $('scope-unit').innerHTML=optionList(options,scope.unit,'Alle Units');$('scope-from').value=scope.from||'';$('scope-to').value=scope.to||'';
  const shown=allContent().filter(withinScope).length;const unknown=(scope.from||scope.to)?allContent().filter(x=>x.language===activeLanguage()&&(!scope.unit||x.unit===scope.unit)&&!pageBounds(x)).length:0;$('scope-count').textContent=shown+' Inhalte'+(unknown?' · '+unknown+' ohne Seite':'');
  $('active-language').textContent=activeLanguage();document.querySelectorAll('[data-active-language]').forEach(x=>x.textContent=activeLanguage());
  $('ai-language').value=activeLanguage();document.querySelectorAll('form [name="language"]').forEach(x=>x.value=activeLanguage());
 }
 function renderScopeView(){syncScope();if(current==='home')renderHome();if(current==='cards')setCards();if(current==='saved')renderSaved();if(current==='notes')renderNotes();if(current==='exercises')renderExercises()}
 function scopeChanged(){let f=pageNum($('scope-from').value),t=pageNum($('scope-to').value);if(f&&t&&f>t){toast('Die Startseite muss vor der Endseite liegen.');$('scope-to').value='';t=null}
  scope.unit=$('scope-unit').value;scope.from=f||'';scope.to=t||'';savedPage=notePage=exercisePage=cardIdx=0;data.meta.studyScope=scope;persist();renderScopeView()}
 function chooseLanguage(language){if(!LANGS.includes(language))return;data.meta.studyLanguage=language;scope.unit='';scope.from='';scope.to='';data.meta.studyScope=scope;
  persist();$('language-setup').classList.remove('setup-visible');syncScope();show('home')}
 const persist=()=>{try{localStorage.setItem(STORAGE_KEY,JSON.stringify(data));return true}catch(e){storageOK=false;toast('Speichern nicht möglich. Bitte Daten als JSON exportieren.');return false}};
 if(storageOK&&!localStorage.getItem(STORAGE_KEY))persist();
 function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),3500)}
 function optionList(values, selected, all='Alle'){return `<option value="">${esc(all)}</option>`+values.map(x=>`<option value="${esc(x)}" ${x===selected?'selected':''}>${esc(x)}</option>`).join('')}
 function choices(items){return [...new Set(items.map(x=>String(x||'').trim()).filter(Boolean))].sort((a,b)=>a.localeCompare(b,'de'))}
 function show(view){if(view==='admin'&&syncRole()==='child'){toast('Dieses Kindgerät hat keinen Elternzugriff.');return}if(current==='admin'&&view!=='admin'){adminUnlocked=false;$('ai-password').value=''}current=view;
  document.body.classList.toggle('admin-mode',view==='admin');document.querySelectorAll('.section').forEach(s=>s.classList.toggle('active',s.id==='view-'+view));
  document.querySelectorAll('[data-go]').forEach(b=>b.classList.toggle('on',b.dataset.go===view));syncScope();
  if(view==='home')renderHome();if(view==='cards')renderCards();if(view==='saved')renderSaved();if(view==='notes')renderNotes();if(view==='exercises')renderExercises();if(view==='admin')renderAdmin();}
 function renderHome(){const v=data.vocab.filter(withinScope),n=data.notes.filter(withinScope),e=data.exercises.filter(withinScope);$('stat-vocab').textContent=v.length;$('stat-star').textContent=v.filter(x=>x.star).length+e.filter(x=>x.star).length;$('stat-notes').textContent=n.length}
 function setCards(){cardSubset=data.vocab.filter(v=>withinScope(v)&&(!cardSavedOnly||v.star));if(cardIdx>=cardSubset.length)cardIdx=0;if(cardIdx<0)cardIdx=0;cardFlipped=false;renderCard()}
 function renderCards(){setCards();$('dir-foreign').classList.toggle('on',cardDir==='toDe');$('dir-german').classList.toggle('on',cardDir==='toForeign')}
 function renderCard(){const item=cardSubset[cardIdx];$('card-index').textContent=item?`${cardIdx+1} von ${cardSubset.length}`:'0 von 0';$('card-saved-indicator').textContent=cardSavedOnly?' · Nur Merkliste':'';$('card-tag').textContent=item?`${item.unit} · ${pageLabel(item)}`:'Keine Karten';$('answer-actions').hidden=!cardFlipped||!item;
  if(!item){$('card-word').textContent='Noch keine Vokabeln';$('card-example').textContent='Im Elternbereich Vokabeln ergänzen.';$('card-hint').textContent='';return}
  const front=cardDir==='toDe'?item.source:item.target;
  const back=cardDir==='toDe'?item.target:item.source;
  $('card-word').textContent=cardFlipped?back:front;
  $('card-example').textContent=cardFlipped?(item.example||''):'';
  $('card-hint').textContent=cardFlipped?'Lösung angezeigt · nochmals tippen zum Umdrehen':'Tippen zum Aufdecken';
  $('card-remember').textContent=item.star?'⭐ Bereits auf Merkliste':'⭐ Kann ich noch nicht';
 }
 function moveCard(step){if(!cardSubset.length)return;cardIdx=(cardIdx+step+cardSubset.length)%cardSubset.length;cardFlipped=false;renderCard()}
 function judgeCard(remember){const item=cardSubset[cardIdx];if(!item)return;const stored=data.vocab.find(v=>v.id===item.id);if(stored){stored.star=remember;queueProgress('vocab',stored)}persist();if(cardSavedOnly&&!remember){cardSubset=cardSubset.filter(v=>v.id!==item.id);if(cardIdx>=cardSubset.length)cardIdx=0;cardFlipped=false;renderCard()}else moveCard(1);toast(remember?'Zur Merkliste hinzugefügt ⭐':'Weiter so! ✓')}
 function pager(group,i,total){const label=$(group+'-index');label.textContent=total?`${i+1} / ${total}`:'0 / 0';const bar=$(group+'-pager');bar.querySelectorAll('button').forEach((b,j)=>b.disabled=!total||(j===0?i===0:i===total-1));}
 function renderSaved(){const vocab=data.vocab.filter(x=>x.star&&withinScope(x)),exercises=data.exercises.filter(x=>x.star&&withinScope(x));const entries=[...vocab.map(v=>({kind:'v',item:v})),...exercises.map(e=>({kind:'e',item:e}))];const size=3,total=Math.ceil(entries.length/size);savedPage=Math.max(0,Math.min(savedPage,total-1));const part=entries.slice(savedPage*size,(savedPage+1)*size);
 $('saved-list').innerHTML=entries.length?part.map(({kind,item:x})=>kind==='v'?`<div class="vocab-item"><div class="row"><div><div class="pair">${esc(x.source)} → ${esc(x.target)}</div><div class="subtitle">Vokabel · ${esc(x.unit)} · ${esc(pageLabel(x))}</div></div><button class="plain-icon danger" title="Aus Merkliste entfernen" data-unstar="${esc(x.id)}">✕</button></div></div>`:`<div class="exercise-item"><div class="exercise-saved-row"><div style="min-width:0"><b>✏️ ${esc(x.title)}</b><div class="subtitle">Übung · ${esc(x.unit)} · ${esc(pageLabel(x))}</div></div><button class="plain-icon" title="Übung öffnen" data-open-ex="${esc(x.id)}">▶</button><button class="plain-icon danger" title="Aus Merkliste entfernen" data-unmark-ex="${esc(x.id)}">✕</button></div></div>`).join(''):'<div class="empty"><span class="big">🌟</span>Noch keine Vokabeln oder Übungen aus diesem Lernbereich gemerkt.</div>';
 $('train-saved').disabled=!vocab.length;$('train-saved-exercises').disabled=!exercises.length;pager('saved',savedPage,total)}

 function splitNote(text,max=225){
   const lines=String(text||'').split(/\n+/).map(x=>x.trim()).filter(Boolean),parts=[];
   for(const line of lines){if(line.length<=max){parts.push(line);continue}
    const sentences=line.match(/[^.!?]+[.!?]+(?:\s+|$)|[^.!?]+$/g)||[line];
    let segment='';for(const one of sentences){if(segment&&segment.length+one.length>max){parts.push(segment.trim());segment=''}
      if(one.length>max){const words=one.match(/\S+\s*/g)||[];for(const word of words){if(segment&&segment.length+word.length>max){parts.push(segment.trim());segment=''}segment+=word}}
      else segment+=one;
    }if(segment.trim())parts.push(segment.trim());
   }
   const slides=[];let out='';for(const part of parts){const add=out?'\n\n'+part:part;if(out&&out.length+add.length>max){slides.push(out);out=part}else out+=add}
   if(out)slides.push(out);return slides.length?slides:[''];
 }
 function renderNotes(){const items=data.notes.filter(withinScope);noteSlides=[];items.forEach(n=>{const text=String(n.content||'')+((n.examples||[]).length?'\n\nBeispiele: '+n.examples.join('\n'):'');splitNote(text,window.innerHeight<720?185:280).forEach((part,i,arr)=>noteSlides.push({note:n,text:part,sub:i+1,total:arr.length}))});
 notePage=Math.max(0,Math.min(notePage,noteSlides.length-1));const slide=noteSlides[notePage];$('notes-list').innerHTML=slide?`<article class="panel"><div class="row"><h2>${esc(slide.note.title)}</h2><span class="pill">${esc(slide.note.unit)}</span></div><p class="subtle">${esc(pageLabel(slide.note))} · Merkblattteil ${slide.sub} von ${slide.total}</p><div class="note-body">${esc(slide.text)}</div><div class="print-tools"><button class="btn secondary small" data-printnote="${esc(slide.note.id)}">🖨️ Ganzes Merkblatt drucken</button></div></article>`:'<div class="empty">📖 Für diesen Lernbereich gibt es noch keine Merkblätter.</div>';
 pager('notes',notePage,noteSlides.length)}
 function exerciseAnswers(e){return Array.isArray(e.answers)&&e.answers.length?e.answers.map(String):String(e.answer||'').split(';;').map(x=>x.trim())}
 function exerciseOptions(e){return Array.isArray(e.options)?e.options.map(String).filter(Boolean):[]}
 const visibleExercises=()=>data.exercises.filter(e=>withinScope(e)&&(!exerciseSavedOnly||e.star));
 function renderExercises(){const items=visibleExercises();exercisePage=Math.max(0,Math.min(exercisePage,items.length-1));$('exercise-only-saved').textContent=exerciseSavedOnly?'⭐ Nur gemerkte':'☆ Gemerkte';$('exercise-only-saved').classList.toggle('on',exerciseSavedOnly);const e=items[exercisePage];if(!e){$('exercise-list').innerHTML='<div class="empty">✏️ '+(exerciseSavedOnly?'Noch keine gemerkten Übungen in diesem Lernbereich.':'Für diesen Lernbereich gibt es noch keine Übungen.')+'</div>';pager('exercise',exercisePage,0);return;}
 const type=e.type||(exerciseOptions(e).length?'dropdown':'text'),options=exerciseOptions(e),blanks=(e.question.match(/___/g)||[]).length;let task='';
 if(type==='listening')task=`<div class="listen-box"><p><b>🎧 Hörübung</b> · Erst hören, dann beantworten.</p><div class="btn-row"><button class="btn secondary small" data-listen="${esc(e.id)}">▶️ Anhören</button><button class="btn light small" data-listen-slow="${esc(e.id)}">🐢 Langsam</button></div></div><p>${esc(e.question)}</p>${answerControl(e,0,type,options)}`;
 else if(blanks){const parts=e.question.split('___');task='<p class="exercise-sentence">'+parts.map((p,i)=>esc(p)+(i<parts.length-1?answerControl(e,i,type,options):'')).join('')+'</p>'}
 else task=`<p style="white-space:pre-wrap">${esc(e.question)}</p>${answerControl(e,0,type,options)}`;
 $('exercise-list').innerHTML=`<article class="panel"><div class="row"><b>${esc(e.title)}</b><span class="pill">${esc(e.unit)}</span></div><div class="subtle" style="margin:3px 0 7px">${esc(pageLabel(e))}</div><div class="exercise-content">${task}</div><div class="exercise-card-actions"><button class="btn small" data-check="${esc(e.id)}">Prüfen</button><button class="btn secondary small ${e.star?'is-saved':''}" data-mark-ex="${esc(e.id)}" aria-pressed="${!!e.star}">${e.star?'⭐ Gemerkt':'☆ Merken'}</button><button class="btn light small" data-pdfone="${esc(e.id)}" title="Diese Aufgabe als PDF herunterladen">↓ PDF</button></div><div data-feedback="${esc(e.id)}" role="status"></div></article>`;
 pager('exercise',exercisePage,items.length)}

 function answerControl(e,index,type,options){return type!=='text'&&options.length?`<select class="blank-select" data-exanswer="${esc(e.id)}" data-index="${index}" aria-label="Antwort für Lücke ${index+1}"><option value="">Bitte wählen</option>${options.map(o=>`<option value="${esc(o)}">${esc(o)}</option>`).join('')}</select>`:`<input class="blank-input" autocomplete="off" data-exanswer="${esc(e.id)}" data-index="${index}" aria-label="Antwort für Lücke ${index+1}" placeholder="Antwort">`}
 function checkExercise(id){const e=data.exercises.find(x=>x.id===id);const inp=Array.from(document.querySelectorAll('[data-exanswer]')).filter(x=>x.dataset.exanswer===id),out=Array.from(document.querySelectorAll('[data-feedback]')).find(x=>x.dataset.feedback===id);if(!e||!inp.length||!out)return;const accepted=exerciseAnswers(e);let right=0;const corrections=[];inp.forEach((x,i)=>{const choices=String(accepted[i]??'').split('|').map(norm).filter(Boolean);const correct=!!norm(x.value)&&choices.includes(norm(x.value));x.classList.toggle('choice-ok',correct);x.classList.toggle('choice-bad',!correct);if(correct)right++;else corrections.push(`Lücke ${i+1}: ${esc(String(accepted[i]||'–').replace(/\|/g,' oder '))}`)});const correct=right===inp.length&&accepted.length===inp.length;out.innerHTML=`<div class="feedback ${correct?'good':'bad'}">${correct?'✓ Alles richtig!':`✓ ${right} von ${inp.length} richtig. ${corrections.join(' · ')}`}${e.type==='listening'&&e.spokenText?'<p style="margin-top:8px;font-weight:400">Hörtext: '+esc(e.spokenText)+'</p>':''}${e.explanation?'<p style="margin-top:6px;font-weight:400">'+esc(e.explanation)+'</p>':''}</div>`}
 const LANG_CODES={'Englisch':'en-US','Spanisch':'es-ES','Französisch':'fr-FR','Italienisch':'it-IT','Latein':'la'};
 function speakText(text,language,slow=false){if(!('speechSynthesis'in window)||!('SpeechSynthesisUtterance'in window))return toast('Auf diesem Gerät ist keine Vorlesefunktion verfügbar.');if(!String(text||'').trim())return toast('Kein Hörtext vorhanden.');const synth=window.speechSynthesis;try{synth.cancel();const u=new SpeechSynthesisUtterance(String(text));u.lang=LANG_CODES[language]||'en-US';u.rate=slow?.72:.94;const voices=synth.getVoices();const same=voices.find(v=>v.lang?.toLowerCase()===u.lang.toLowerCase())||voices.find(v=>v.lang?.slice(0,2).toLowerCase()===u.lang.slice(0,2).toLowerCase());if(same)u.voice=same;u.onerror=()=>toast('Vorlesen fehlgeschlagen. Prüfe die installierten Sprachstimmen.');synth.speak(u)}catch{toast('Audioausgabe nicht verfügbar.')}}
 // PDF: offline erzeugte A4-Textdokumente, ohne externe Fonts, Bilder oder Netzwerkzugriff.
 const CP1252={'€':128,'‚':130,'ƒ':131,'„':132,'…':133,'†':134,'‡':135,'ˆ':136,'‰':137,'Š':138,'‹':139,'Œ':140,'Ž':142,'‘':145,'’':146,'“':147,'”':148,'•':149,'–':150,'—':151,'˜':152,'™':153,'š':154,'›':155,'œ':156,'ž':158,'Ÿ':159};
 function pdfByteString(str){let out='';for(const c of String(str||'')){const n=c.codePointAt(0);if(n>=32&&n<=126||n>=160&&n<=255)out+=String.fromCharCode(n);else if(CP1252[c])out+=String.fromCharCode(CP1252[c]);else if(c==='\n'||c==='\r'||c==='\t')out+=' ';else out+='?'}return out}
 function pdfLiteral(str){const s=pdfByteString(str);let out='(';for(let i=0;i<s.length;i++){const c=s.charCodeAt(i);if(c===40||c===41||c===92)out+='\\'+String.fromCharCode(c);else out+=String.fromCharCode(c)}return out+')'}
 function pdfUtf8LikeBytes(s){const buf=new Uint8Array(s.length);for(let i=0;i<s.length;i++)buf[i]=s.charCodeAt(i)&255;return buf}
 function buildPdf(exercises,solutions=false){
  const W=595.28,H=841.89,M=51,right=W-M,usable=W-2*M,pages=[];let commands=[],y=H-55,pageNumber=0;
  function textLine(t,x,yy,size=11,bold=false){commands.push(`BT /${bold?'F2':'F1'} ${size} Tf 1 0 0 1 ${x.toFixed(1)} ${yy.toFixed(1)} Tm ${pdfLiteral(t)} Tj ET`)}
  function line(y0){commands.push(`0.82 0.83 0.89 RG 0.8 w ${M} ${y0.toFixed(1)} m ${right.toFixed(1)} ${y0.toFixed(1)} l S`)}
  function finishPage(){textLine('SprachKompass | '+(solutions?'Lösungen':'Übungsblatt')+' | Seite '+pageNumber,M,29,8,false);pages.push(commands.join('\n'));}
  function newPage(){if(pageNumber)finishPage();pageNumber++;commands=[];y=H-51;textLine('SPRACHKOMPASS',M,y,15,true);textLine(solutions?'LÖSUNGSBLATT':'ÜBUNGSBLATT',W-171,y,11,true);y-=18;line(y);y-=23;}
  function reserve(points){if(y-points<65)newPage()}
  // Wrap according to approximate Helvetica widths; safety margin for wide letters.
  function wrapText(txt,size=11,maxWidth=usable){const result=[];for(const paragraph of String(txt||'').split(/\n/)){
    if(!paragraph.trim()){result.push('');continue}let row='';const words=paragraph.split(/\s+/);for(let word of words){while(word.length>1&&word.length*size*.58>maxWidth){let count=Math.max(1,Math.floor(maxWidth/(size*.6)));const chunk=word.slice(0,count);if(row){result.push(row);row=''}result.push(chunk);word=word.slice(count)}const candidate=row?row+' '+word:word;if(candidate.length*size*.54>maxWidth&&row){result.push(row);row=word}else row=candidate}result.push(row)}return result}
  function para(s,size=11,bold=false,indent=0,spacing=1.42){const lines=wrapText(s,size,usable-indent);for(const chunk of lines){reserve(size*spacing+2);if(chunk)textLine(chunk,M+indent,y,size,bold);y-=size*spacing;}y-=3;}
  newPage();
  para(`${activeLanguage()} · ${scope.unit||'Alle Units'} · ${scope.from||scope.to?'Seiten '+(scope.from||'Anfang')+' bis '+(scope.to||'Ende'):'alle Seiten'} · ${new Date().toLocaleDateString('de-DE')}`,9,false);y-=9;
  for(let i=0;i<exercises.length;i++){
   const e=exercises[i],type=e.type||(exerciseOptions(e).length?'dropdown':'text'),options=exerciseOptions(e),answers=exerciseAnswers(e);
   const intro=`${i+1}. ${e.title||'Übung'}`;reserve(95);para(intro,13,true,0,1.34);
   para(`${e.unit||'Ohne Kapitel'} · ${pageLabel(e)} · ${type==='listening'?'Hörverständnis':type==='dropdown'?'Auswahl-Lückentext':'Lückentext'}`,9,false);
   const q=(e.question||'').replace(/___/g,'_____________');para(q,11,false,0,1.55);
   if(!solutions){if(type==='listening'){para('Audio: zum Anhören die App öffnen.',9,false)}
    if(options.length)para('Auswahl: '+options.join('  |  '),10,false,0,1.4);
    if(!String(e.question||'').includes('___'))para('Antwort: _____________________________________________________',10,false);
    y-=20;
   }else{
    para('Lösung: '+answers.map(x=>x.replace(/\|/g,' oder ')).join(' / '),10,true);
    if(e.explanation)para('Erklärung: '+e.explanation,10,false);
    if(type==='listening'&&e.spokenText)para('Hörtext: '+e.spokenText,10,false);
    y-=15;
   }
   line(y);y-=18;
  }
  finishPage();
  const objs=[];const add=(s)=>{objs.push(s);return objs.length};
  const catalog=add('');const pagesRoot=add('');const font1=add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');const font2=add('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
  const leaf=[];
  for(const stream of pages){const streamNo=add(`<< /Length ${stream.length} >>\nstream\n${stream}\nendstream`);const pageNo=add(`<< /Type /Page /Parent ${pagesRoot} 0 R /MediaBox [0 0 ${W} ${H}] /Resources << /Font << /F1 ${font1} 0 R /F2 ${font2} 0 R >> >> /Contents ${streamNo} 0 R >>`);leaf.push(pageNo)}
  objs[pagesRoot-1]=`<< /Type /Pages /Kids [${leaf.map(n=>n+' 0 R').join(' ')}] /Count ${leaf.length} >>`;
  objs[catalog-1]=`<< /Type /Catalog /Pages ${pagesRoot} 0 R >>`;
  let pdf='%PDF-1.4\n%PDFbinary\n',offsets=[0];for(let i=0;i<objs.length;i++){offsets.push(pdf.length);pdf+=`${i+1} 0 obj\n${objs[i]}\nendobj\n`}
  const pos=pdf.length;pdf+='xref\n0 '+(objs.length+1)+'\n0000000000 65535 f \n';for(let i=1;i<offsets.length;i++)pdf+=String(offsets[i]).padStart(10,'0')+' 00000 n \n';pdf+=`trailer\n<< /Size ${objs.length+1} /Root ${catalog} 0 R >>\nstartxref\n${pos}\n%%EOF\n`;
  return pdfUtf8LikeBytes(pdf);
 }
 function exportExercisesPdf(solutions=false,ids=null){const items=data.exercises.filter(e=>withinScope(e)&&(!exerciseSavedOnly||e.star)&&(!ids||ids.includes(e.id)));if(!items.length)return toast('Keine passenden Übungen zum Herunterladen.');const stem=activeLanguage().toLowerCase()+'_'+(scope.unit||'alle-units').replace(/[^\p{L}\d_-]+/gu,'-').slice(0,34);const name='SprachKompass_'+(solutions?'Loesungen':'Uebungen')+'_'+stem+'.pdf';const blob=new Blob([buildPdf(items,solutions)],{type:'application/pdf'});downloadBlob(name,blob);toast((solutions?'Lösungen':'Übungsblatt')+' als PDF heruntergeladen ('+items.length+' Aufgaben).')}
 function downloadBlob(name,blob){const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000)}

 function printNotes(ids){const items=data.notes.filter(n=>ids.includes(n.id));if(!items.length)return toast('Keine Merkblätter zum Drucken vorhanden.');$('print-sheet').innerHTML=`<h1>SprachKompass · Merkblätter</h1><div class="print-caption">Eigene Lernzusammenfassung · erstellt am ${esc(new Date().toLocaleDateString('de-DE'))}</div>`+items.map(n=>`<section class="printed-item"><h2>${esc(n.title)}</h2><div class="print-caption">${esc(n.language)} · ${esc(n.unit)} · ${esc(pageLabel(n))}</div><p>${esc(n.content)}</p>${(n.examples||[]).map(x=>`<div class="example">${esc(x)}</div>`).join('')}</section>`).join('');window.print()}
 async function pinDigest(pin,salt){const text=salt+':'+pin;if(typeof crypto!=='undefined'&&crypto.subtle){const bytes=new TextEncoder().encode(text);const digest=await crypto.subtle.digest('SHA-256',bytes);return Array.from(new Uint8Array(digest)).map(x=>x.toString(16).padStart(2,'0')).join('')}
  let n=2166136261;for(let i=0;i<text.length;i++){n^=text.charCodeAt(i);n=Math.imul(n,16777619)}return 'local-'+(n>>>0).toString(16)}
 async function setPin(pin){const salt=uid();data.meta.pinSalt=salt;data.meta.pinHash=await pinDigest(pin,salt);persist()}
 function renderAdmin(){if(!adminUnlocked){$('admin-content').classList.add('hidden');$('admin-lock').classList.add('hidden');$('admin-gate').classList.remove('hidden');$('admin-gate').innerHTML=data.meta.pinHash?`<h2>🔐 Eltern-PIN eingeben</h2><form id="pin-unlock"><div class="field"><label>PIN</label><input type="password" inputmode="numeric" name="pin" maxlength="8" autocomplete="off" required autofocus placeholder="4–8 Ziffern"></div><button class="btn" type="submit">Entsperren</button></form>`:`<h2>🔐 Elternbereich einrichten</h2><p class="muted">Lege einmalig eine PIN fest. Das Kind kann den Lernbereich danach ohne PIN nutzen.</p><form id="pin-setup"><div class="field"><label>Neue PIN (4–8 Ziffern)</label><input name="pin" type="password" inputmode="numeric" minlength="4" maxlength="8" pattern="[0-9]{4,8}" required placeholder="PIN festlegen"></div><button class="btn" type="submit">PIN speichern</button></form>`;return}
  $('admin-gate').classList.add('hidden');$('admin-content').classList.remove('hidden');$('admin-lock').classList.remove('hidden');renderAdminLists()}
 function renderAdminLists(){const q=norm($('vocab-search').value);const filtered=data.vocab.filter(x=>x.language===activeLanguage()&&(!q||norm([x.source,x.target,x.unit,x.language].join(' ')).includes(q)));$('admin-vocab-count').textContent=filtered.length+' Einträge';$('admin-vocab-list').innerHTML=filtered.length?filtered.slice(0,150).map(v=>`<div class="vocab-item"><div class="row"><div><div class="pair">${esc(v.source)} → ${esc(v.target)}</div><div class="subtitle">${esc(v.unit)} · ${esc(pageLabel(v))}</div></div><div class="list-item-actions"><button class="plain-icon" data-editvoc="${esc(v.id)}" title="Bearbeiten">✎</button><button class="plain-icon danger" data-delete="vocab:${esc(v.id)}" title="Löschen">✕</button></div></div></div>`).join(''):'<p class="muted">Keine Vokabeln gefunden.</p>';if(filtered.length>150)$('admin-vocab-list').innerHTML+='<p class="subtle">Es werden die ersten 150 angezeigt. Über die Suche weitere Wörter finden.</p>';
  $('admin-notes-list').innerHTML=data.notes.some(x=>x.language===activeLanguage())?data.notes.filter(x=>x.language===activeLanguage()).map(n=>`<div class="note-item row"><div><b>${esc(n.title)}</b><div class="subtitle">${esc(n.unit)} · ${esc(pageLabel(n))}</div></div><div class="list-item-actions"><button class="plain-icon" data-editnote="${esc(n.id)}">✎</button><button class="plain-icon danger" data-delete="notes:${esc(n.id)}">✕</button></div></div>`).join(''):'<p class="muted">Noch keine Merkblätter.</p>';
  $('admin-exercises-list').innerHTML=data.exercises.some(x=>x.language===activeLanguage())?data.exercises.filter(x=>x.language===activeLanguage()).map(n=>`<div class="exercise-item row"><div><b>${esc(n.title)}</b><div class="subtitle">${esc(n.unit)} · ${esc(pageLabel(n))}</div></div><div class="list-item-actions"><button class="plain-icon" data-editexercise="${esc(n.id)}">✎</button><button class="plain-icon danger" data-delete="exercises:${esc(n.id)}">✕</button></div></div>`).join(''):'<p class="muted">Noch keine Übungen.</p>'}
 function normalizedPages(v){const p=pageNum(v.pageStart),q=pageNum(v.pageEnd),a=p||q,b=q||p;return {pageStart:a||null,pageEnd:b||null}}
 function validPages(v){const p=pageNum(v.pageStart),q=pageNum(v.pageEnd);return !(p&&q&&p>q)}
 function addVocab(v){if(!validPages(v))return 'invalid';const o={id:uid(),source:String(v.source||'').trim(),target:String(v.target||'').trim(),language:activeLanguage(),unit:String(v.unit||'Ohne Kapitel').trim(),example:String(v.example||'').trim(),star:false,...normalizedPages(v),createdAt:now()};if(!o.source||!o.target)return 'invalid';const exists=data.vocab.find(x=>norm(x.language)===norm(o.language)&&norm(x.unit)===norm(o.unit)&&norm(x.source)===norm(o.source)&&norm(x.target)===norm(o.target)&&JSON.stringify(pageBounds(x))===JSON.stringify(pageBounds(o)));if(exists)return 'duplicate';data.vocab.push(o);return 'added'}
 function addNote(v){if(!validPages(v))return false;if(!String(v.title||'').trim()||!String(v.content||'').trim())return false;data.notes.push({id:uid(),title:String(v.title).trim(),language:activeLanguage(),unit:v.unit||'Ohne Kapitel',content:String(v.content),examples:(v.examples||[]).map(String).filter(Boolean),...normalizedPages(v),createdAt:now()});return true}
 function addExercise(v){if(!validPages(v))return false;if(!String(v.question||'').trim()||!String(v.answer||'').trim())return false;const answer=String(v.answer).trim(),answers=Array.isArray(v.answers)&&v.answers.length?v.answers.map(String):answer.split(';;').map(x=>x.trim());const type=['dropdown','text','listening'].includes(v.type)?v.type:'text';const options=Array.isArray(v.options)?v.options.map(String).filter(Boolean):String(v.options||'').split('\n').map(x=>x.trim()).filter(Boolean);if(type==='listening'&&!String(v.spokenText||'').trim())return false;if(type==='dropdown'&&options.length<2)return false;const blanks=(String(v.question).match(/___/g)||[]).length;if(type!=='listening'&&blanks>0&&answers.length!==blanks)return false;data.exercises.push({id:uid(),title:String(v.title||'Übung').trim(),language:activeLanguage(),unit:v.unit||'Ohne Kapitel',question:String(v.question),answer,answers,explanation:String(v.explanation||''),type,options,spokenText:String(v.spokenText||''),...normalizedPages(v),createdAt:now()});return true}
 function formObj(form){return Object.fromEntries(new FormData(form).entries())}
 let editing=null;
 function inputField(name,label,value,textarea=false,hint=''){return `<div class="field"><label for="edit-${name}">${esc(label)}</label>${textarea?`<textarea id="edit-${name}" name="${name}">${esc(value||'')}</textarea>`:`<input id="edit-${name}" name="${name}" value="${esc(value||'')}">`}${hint?`<div class="field-help">${esc(hint)}</div>`:''}</div>`}
 function openEditor(group,id){const item=data[group]?.find(v=>v.id===id);if(!item)return;editing={group,id};$('editor-title').textContent=group==='vocab'?'Vokabel bearbeiten':group==='notes'?'Merkblatt bearbeiten':'Übung bearbeiten';let fields=inputField('unit','Kapitel / Unit',item.unit)+inputField('pageStart','Buchseite ab (optional)',item.pageStart||'')+inputField('pageEnd','Bis Buchseite (optional)',item.pageEnd||'');
  if(group==='vocab')fields+=inputField('source','Fremdsprachliches Wort',item.source)+inputField('target','Deutsch',item.target)+inputField('example','Eigenes Beispiel',item.example);
  if(group==='notes')fields+=inputField('title','Titel / Grammatikthema',item.title)+inputField('content','Regeln und Erklärungen',item.content,true)+inputField('examples','Eigene Beispiele (ein Beispiel pro Zeile)',(item.examples||[]).join('\n'),true);
  if(group==='exercises')fields+=`<div class="field"><label>Aufgabentyp</label><select name="type">${[['dropdown','Dropdown-Lückentext'],['text','Texteingabe'],['listening','Hörübung']].map(([x,l])=>`<option value="${x}" ${item.type===x?'selected':''}>${l}</option>`).join('')}</select></div>`+inputField('title','Titel',item.title)+inputField('question','Frage / Text (___ als Lücke)',item.question,true)+inputField('answer','Lösung (mehrere Lücken mit ;; trennen)',exerciseAnswers(item).join(' ;; '))+inputField('options','Dropdown-Antworten (je Zeile)',(item.options||[]).join('\n'),true)+inputField('spokenText','Vorlesetext (nur Hörübung)',item.spokenText||'',true)+inputField('explanation','Erklärung',item.explanation||'',true);
  $('editor-fields').innerHTML=fields;const dialog=$('editor-dialog');if(typeof dialog.showModal==='function')dialog.showModal();else dialog.setAttribute('open','');
 }
 function saveEditor(ev){ev.preventDefault();if(!editing)return;const item=data[editing.group]?.find(v=>v.id===editing.id);if(!item)return;const v=formObj($('editor-form'));if(!v.unit.trim())return toast('Bitte Kapitel eingeben.');if(!validPages(v))return toast('Seitenbereich ungültig: Start liegt nach Ende.');if(editing.group==='vocab'){if(!v.source.trim()||!v.target.trim())return toast('Wort und Übersetzung erforderlich.');const dup=data.vocab.some(x=>x.id!==item.id&&norm(x.language)===norm(activeLanguage())&&norm(x.unit)===norm(v.unit)&&norm(x.source)===norm(v.source)&&norm(x.target)===norm(v.target)&&JSON.stringify(pageBounds(x))===JSON.stringify(pageBounds(v)));if(dup)return toast('Dieses Wortpaar existiert bereits.');Object.assign(item,{language:activeLanguage(),unit:v.unit.trim(),...normalizedPages(v),source:v.source.trim(),target:v.target.trim(),example:v.example.trim()})}
  if(editing.group==='notes'){if(!v.title.trim()||!v.content.trim())return toast('Titel und Erklärung erforderlich.');Object.assign(item,{language:activeLanguage(),unit:v.unit.trim(),...normalizedPages(v),title:v.title.trim(),content:v.content.trim(),examples:v.examples.split('\n').map(x=>x.trim()).filter(Boolean)})}
  if(editing.group==='exercises'){if(!v.question.trim()||!v.answer.trim())return toast('Frage und Lösung erforderlich.');const ans=v.answer.split(';;').map(x=>x.trim()),n=(v.question.match(/___/g)||[]).length;if(v.type!=='listening'&&n&&ans.length!==n)return toast('Die Anzahl der Lösungen muss der Anzahl der Lücken entsprechen.');if(v.type==='listening'&&!v.spokenText.trim())return toast('Hörtext fehlt.');if(v.type==='dropdown'&&v.options.split('\n').filter(x=>x.trim()).length<2)return toast('Für Dropdowns mindestens zwei Auswahlmöglichkeiten eintragen.');Object.assign(item,{language:activeLanguage(),unit:v.unit.trim(),...normalizedPages(v),title:v.title.trim(),type:v.type,question:v.question,answer:v.answer,answers:ans,options:v.options.split('\n').map(x=>x.trim()).filter(Boolean),spokenText:v.spokenText,explanation:v.explanation})}
  persist();renderAdminLists();$('editor-dialog').close?.();$('editor-dialog').removeAttribute('open');editing=null;toast('Änderungen gespeichert')}
 function editVocab(id){openEditor('vocab',id)}
 function editNote(id){openEditor('notes',id)}
 function editExercise(id){openEditor('exercises',id)}
 function download(name,content,type){const url=URL.createObjectURL(new Blob([content],{type}));const a=document.createElement('a');a.href=url;a.download=name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),10000)}
 function backup(){download('sprachkompass-backup-'+new Date().toISOString().slice(0,10)+'.json',JSON.stringify({format:'sprachkompass-v1',exportedAt:now(),vocab:data.vocab,notes:data.notes,exercises:data.exercises,meta:{createdAt:data.meta.createdAt}},null,2),'application/json')}
 const csvEscape=s=>'"'+String(s??'').replace(/"/g,'""')+'"';
 function exportCsv(){const rows=[['sprache','kapitel','seite_ab','seite_bis','fremdsprache','deutsch','beispiel','merkliste'],...data.vocab.map(v=>[v.language,v.unit,v.pageStart||'',v.pageEnd||'',v.source,v.target,v.example,v.star?'ja':'nein'])];download('sprachkompass-vokabeln.csv','\ufeff'+rows.map(r=>r.map(csvEscape).join(';')).join('\r\n'),'text/csv;charset=utf-8')}
 function parseDelimited(text){const line=text.replace(/^\ufeff/,'').split(/\r?\n/)[0]||'';const delim=(line.match(/;/g)||[]).length>=(line.match(/\t/g)||[]).length&& (line.match(/;/g)||[]).length>=(line.match(/,/g)||[]).length?';':(line.match(/\t/g)||[]).length>=(line.match(/,/g)||[]).length?'\t':',';const rows=[],row=[];let val='',q=false;const s=text.replace(/^\ufeff/,'');for(let i=0;i<s.length;i++){const c=s[i];if(c==='"'){if(q&&s[i+1]==='"'){val+='"';i++}else q=!q}else if(!q&&c===delim){row.push(val);val=''}else if(!q&&(c==='\r'||c==='\n')){if(c==='\r'&&s[i+1]==='\n')i++;row.push(val);if(row.some(x=>x.trim()))rows.push(row.slice());row.length=0;val=''}else val+=c}row.push(val);if(row.some(x=>x.trim()))rows.push(row);return rows}
 function extractImportedFile(text,name){if(name.toLowerCase().endsWith('.json')||text.trim().startsWith('{')||text.trim().startsWith('[')){const parsed=JSON.parse(text);const arr=Array.isArray(parsed)?parsed:parsed.vocab;if(!Array.isArray(arr))throw Error('Keine Vokabelliste im JSON gefunden');return arr.map(v=>({language:v.language||v.sprache,unit:v.unit||v.kapitel,source:v.source||v.fremdsprache,target:v.target||v.deutsch,example:v.example||v.beispiel,pageStart:v.pageStart||v.seite_ab,pageEnd:v.pageEnd||v.seite_bis}))}
  const rows=parseDelimited(text);if(rows.length<2)throw Error('Die Datei enthält keine Datenzeilen.');const headings=rows.shift().map(norm);const index=(...names)=>headings.findIndex(x=>names.includes(x));const a=index('sprache','language','lang'),b=index('kapitel','unit','lektion'),c=index('fremdsprache','source','wort','vokabel','english','englisch','spanisch'),d=index('deutsch','target','übersetzung','uebersetzung','translation'),e=index('beispiel','example'),f=index('seite_ab','seitennummer','pagestart','seite'),g=index('seite_bis','pageend');if(c<0||d<0)throw Error('Spalten „fremdsprache“ und „deutsch“ fehlen.');return rows.map(r=>({language:a>=0?r[a]:'Englisch',unit:b>=0?r[b]:'Ohne Kapitel',source:r[c],target:r[d],example:e>=0?r[e]:'',pageStart:f>=0?r[f]:'',pageEnd:g>=0?r[g]:''}))}
 async function loadPhotos(files){const list=Array.from(files).slice(0,6);if(!list.length)return [];const photoData=[];for(const file of list){if(!file.type.startsWith('image/'))throw Error('Nur Bilder erlaubt');if(file.size>12*1024*1024)throw Error('Eine Bilddatei ist größer als 12 MB');photoData.push(await resizeFile(file))}return photoData}
 function resizeFile(file){return new Promise((resolve,reject)=>{const img=new Image(),u=URL.createObjectURL(file);img.onload=()=>{URL.revokeObjectURL(u);const max=1700,scale=Math.min(1,max/Math.max(img.width,img.height)),can=document.createElement('canvas');can.width=Math.round(img.width*scale);can.height=Math.round(img.height*scale);const ctx=can.getContext('2d');ctx.fillStyle='#fff';ctx.fillRect(0,0,can.width,can.height);ctx.drawImage(img,0,0,can.width,can.height);resolve(can.toDataURL('image/jpeg',.82))};img.onerror=()=>{URL.revokeObjectURL(u);reject(Error('Bild konnte nicht gelesen werden'))};img.src=u})}
 function renderPreviews(){const el=$('ai-previews');el.innerHTML='';for(const file of Array.from($('ai-files').files).slice(0,6)){const img=document.createElement('img');img.src=URL.createObjectURL(file);img.alt=file.name;img.onload=()=>URL.revokeObjectURL(img.src);el.append(img)}if($('ai-files').files.length>6)toast('Es werden maximal 6 Fotos verwendet.')}
 async function runAI(){if(!$('ai-files').files.length)return toast('Bitte zuerst Fotos auswählen');if(!$('ai-consent').checked)return toast('Bitte Datenschutz-Hinweis bestätigen');if(!navigator.onLine)return toast('Für den KI-Import brauchst du Internet');const password=$('ai-password').value;if(!password)return toast('Server-Passwort eingeben (siehe README)');const btn=$('ai-run');btn.disabled=true;btn.textContent='Analysiere Seiten …';$('ai-status').textContent='Fotos werden vorbereitet und dann nur für die KI-Analyse an den konfigurierten Server übertragen.';try{const images=await loadPhotos($('ai-files').files);const response=await fetch('./api/generate',{method:'POST',headers:{'Content-Type':'application/json','X-Admin-Password':password},body:JSON.stringify({language:activeLanguage(),unit:$('ai-unit').value.trim()||'Ohne Kapitel',pageStart:$('ai-page-start').value,pageEnd:$('ai-page-end').value,task:$('ai-task').value,focus:$('ai-topic').value.trim(),images})});let result;try{result=await response.json()}catch{throw Error('Kein KI-Server erreichbar. Bitte Hosting/Server konfigurieren.')}if(!response.ok)throw Error(result.error||`Serverfehler ${response.status}`);aiDraft={detection:result.detection||{},vocabulary:Array.isArray(result.vocabulary)?result.vocabulary:[],grammar:Array.isArray(result.grammar)?result.grammar:[],exercises:Array.isArray(result.exercises)?result.exercises:[]};renderAiReview();$('ai-status').textContent='Entwurf erstellt. Bitte jeden Eintrag kontrollieren, dann freigeben.';toast('KI-Vorschläge eingelesen. Jetzt bitte prüfen.')}catch(err){$('ai-status').textContent='Fehler: '+err.message;toast('KI-Import fehlgeschlagen. Details unterhalb des Buttons.')}finally{btn.disabled=false;btn.textContent='✨ Seiten analysieren';$('ai-password').value=''}}
 function reviewPageFields(x){const start=x.pageStart??$('ai-page-start').value,end=x.pageEnd??$('ai-page-end').value;return `<div class="inline-fields pages-fields"><div class="field"><label>Buchseite ab</label><input data-f="pageStart" type="number" min="1" value="${esc(start||'')}"></div><div class="field"><label>bis Seite</label><input data-f="pageEnd" type="number" min="1" value="${esc(end||'')}"></div></div>`}
 function renderAiReview(){const p=$('ai-review');p.classList.remove('hidden');const v=aiDraft.vocabulary,g=aiDraft.grammar,e=aiDraft.exercises,det=aiDraft.detection||{};const detected=(Array.isArray(det.topics)?det.topics:[]).slice(0,8);p.innerHTML=`<h2>Ergebnisse kontrollieren</h2><div class="topic-summary"><b>Erkannt:</b> ${esc(det.category||'Nicht eindeutig')} ${detected.map(x=>`<span class="chip">${esc(x)}</span>`).join('')}<p class="subtle">Du kannst die Zuordnung und jeden Vorschlag vor dem Speichern bearbeiten.</p></div><div class="notice warn">KI kann Text, Übersetzungen und Aufgaben falsch erkennen. Erst nach deiner Prüfung werden Einträge gespeichert. Ungewisse Einträge bitte abwählen.</div><p class="subtle">${v.length} Vokabeln · ${g.length} Merkblätter · ${e.length} Übungen</p>`+
  (v.length?'<h3>🗂️ Vokabeln</h3>'+v.map((x,i)=>`<div class="review-entry" data-review="vocab:${i}"><label class="review-head"><input type="checkbox" data-include checked>Vokabel ${i+1}</label><div class="inline-fields"><div class="field"><label>Fremdsprache</label><input data-f="source" value="${esc(x.source)}"></div><div class="field"><label>Deutsch</label><input data-f="target" value="${esc(x.target)}"></div></div><div class="field"><label>Beispiel (optional)</label><input data-f="example" value="${esc(x.example||'')}"></div><div class="field"><label>Kapitel</label><input data-f="unit" value="${esc(x.unit||$('ai-unit').value||'Ohne Kapitel')}"></div>${reviewPageFields(x)}</div>`).join(''):'')+
  (g.length?'<h3>📖 Merkblätter</h3>'+g.map((x,i)=>`<div class="review-entry" data-review="grammar:${i}"><label class="review-head"><input type="checkbox" data-include checked>Merkblatt ${i+1}</label><div class="field"><label>Titel</label><input data-f="title" value="${esc(x.title)}"></div><div class="field"><label>Erklärung / Regeln</label><textarea data-f="content">${esc(x.content||'')}</textarea></div><div class="field"><label>Beispiele (eine Zeile pro Beispiel)</label><textarea data-f="examples">${esc((x.examples||[]).join('\n'))}</textarea></div><div class="field"><label>Kapitel</label><input data-f="unit" value="${esc(x.unit||$('ai-unit').value||'Ohne Kapitel')}"></div><label class="access-inline"><input data-merge type="checkbox" checked> Passendes vorhandenes Merkblatt erweitern (gleiche Sprache, Kapitel und Titel)</label>${reviewPageFields(x)}</div>`).join(''):'')+
  (e.length?'<h3>✏️ Übungen</h3>'+e.map((x,i)=>`<div class="review-entry" data-review="exercises:${i}"><label class="review-head"><input type="checkbox" data-include checked>Übung ${i+1}</label><div class="field"><label>Titel</label><input data-f="title" value="${esc(x.title||'Übung')}"></div><div class="field"><label>Frage</label><textarea data-f="question">${esc(x.question||'')}</textarea></div><div class="field"><label>Typ</label><select data-f="type"><option value="dropdown" ${x.type==='dropdown'?'selected':''}>Dropdown-Lückentext</option><option value="text" ${x.type==='text'?'selected':''}>Texteingabe</option><option value="listening" ${x.type==='listening'?'selected':''}>Hörverständnis</option></select></div><div class="field"><label>Antwort (mehrere: ;;)</label><input data-f="answer" value="${esc((x.answers||[]).length?x.answers.join(' ;; '):(x.answer||''))}"></div><div class="field"><label>Dropdown-Optionen (je Zeile)</label><textarea data-f="options">${esc((x.options||[]).join('\n'))}</textarea></div><div class="field"><label>Hörtext</label><textarea data-f="spokenText">${esc(x.spokenText||'')}</textarea></div><div class="field"><label>Erklärung</label><input data-f="explanation" value="${esc(x.explanation||'')}"></div><div class="field"><label>Kapitel</label><input data-f="unit" value="${esc(x.unit||$('ai-unit').value||'Ohne Kapitel')}"></div>${reviewPageFields(x)}</div>`).join(''):'')+
  `<div class="btn-row"><button class="btn" id="ai-approve">✓ Markierte Inhalte speichern</button><button class="btn secondary" id="ai-cancel">Entwurf verwerfen</button></div>`;
  if(!v.length&&!g.length&&!e.length)p.innerHTML+='<p>Es wurden keine erkennbaren Inhalte zurückgegeben.</p>'}
 function approveAI(){let added=0,dupes=0,invalid=0,merged=0;const lang=$('ai-language').value;document.querySelectorAll('[data-review]').forEach(el=>{if(!el.querySelector('[data-include]').checked)return;const [kind]=el.dataset.review.split(':');const get=n=>el.querySelector(`[data-f="${n}"]`)?.value||'';let success=false;if(kind==='vocab'){const s=addVocab({source:get('source'),target:get('target'),example:get('example'),unit:get('unit'),language:lang,pageStart:get('pageStart'),pageEnd:get('pageEnd')});if(s==='duplicate')dupes++;else if(s==='added')success=true;else invalid++}
  if(kind==='grammar'){const note={title:get('title'),content:get('content'),examples:get('examples').split('\n').filter(Boolean),unit:get('unit'),language:lang,pageStart:get('pageStart'),pageEnd:get('pageEnd')};const prior=el.querySelector('[data-merge]')?.checked?data.notes.find(x=>norm(x.title)===norm(note.title)&&norm(x.language)===norm(note.language)&&norm(x.unit)===norm(note.unit)):null;if(prior){const paras=[prior.content.trim(),note.content.trim()];prior.content=paras.filter((x,i)=>x&&paras.indexOf(x)===i).join('\n\n');prior.examples=choices([...(prior.examples||[]),...note.examples]);if(pageNum(note.pageStart)){const pb=pageBounds(prior),nb=pageBounds(note);prior.pageStart=pb?Math.min(pb[0],nb[0]):nb[0];prior.pageEnd=pb?Math.max(pb[1],nb[1]):nb[1]}merged++;success=true}else success=addNote(note)}
  if(kind==='exercises')success=addExercise({title:get('title'),question:get('question'),answer:get('answer'),options:get('options'),spokenText:get('spokenText'),type:get('type'),explanation:get('explanation'),unit:get('unit'),language:lang,pageStart:get('pageStart'),pageEnd:get('pageEnd')});if(!success&&kind!=='vocab')invalid++;if(success)added++});persist();aiDraft=null;$('ai-review').classList.add('hidden');$('ai-review').innerHTML='';renderAdminLists();toast(`${added} Inhalte übernommen · ${merged} Merkblätter ergänzt · ${dupes} Dubletten${invalid?' · '+invalid+' ungültige Einträge':''}`)}
 function demoAI(){const unit=$('ai-unit').value.trim()||'Unit 3';const pg=pageNum($('ai-page-start').value);const pend=pageNum($('ai-page-end').value)||pg;aiDraft={detection:{category:'Grammatik + Vokabular',topics:['Simple Past','Present Perfect']},vocabulary:[{source:'already',target:'schon, bereits',example:'I have already finished my project.',unit},{source:'yesterday',target:'gestern',example:'We met at the library yesterday.',unit}],grammar:[{title:'Simple Past und Present Perfect',unit,content:'Simple Past: abgeschlossene Handlung mit festem Zeitpunkt in der Vergangenheit, z. B. yesterday oder last week.\n\nPresent Perfect: Handlung mit Bezug zur Gegenwart oder Lebenserfahrung ohne konkret genannten abgeschlossenen Zeitpunkt. Bildung: have/has + past participle.',examples:['We visited the museum yesterday. – Simple Past','She has lost her keys. – Present Perfect']}],exercises:[{title:'Simple Past oder Present Perfect?',question:'I ___ my grandma last Sunday.',answer:'visited',options:['visited','have visited','visit'],type:'dropdown',explanation:'Last Sunday ist ein abgeschlossener Zeitpunkt.',unit},{title:'Simple Past oder Present Perfect?',question:'She ___ her homework already.',answer:'has finished',options:['finished','has finished','finishes'],type:'dropdown',explanation:'Already kann bei einem aktuellen Ergebnis auf Present Perfect hinweisen.',unit},{title:'Hörübung: Ein Ausflug',type:'listening',spokenText:'Last weekend, Daniel visited his uncle. They cooked pasta and watched a film together.',question:'What did Daniel and his uncle cook?',answer:'pasta',options:['pizza','pasta','soup'],explanation:'They cooked pasta.',unit}]};if(activeLanguage()!=='Englisch'){aiDraft={detection:{category:'Vokabular',topics:['Alltagssprache']},vocabulary:[{source:activeLanguage()==='Spanisch'?'la casa':activeLanguage()==='Französisch'?'la maison':activeLanguage()==='Italienisch'?'la casa':'amicus',target:activeLanguage()==='Latein'?'der Freund':'das Haus',unit,pageStart:pg,pageEnd:pend,example:''}],grammar:[],exercises:[]}}else{for(const x of [...aiDraft.vocabulary,...aiDraft.grammar,...aiDraft.exercises]){x.pageStart=pg;x.pageEnd=pend}}renderAiReview();$('ai-status').textContent='Beispielanalyse ohne Upload oder KI. Du kannst alles bearbeiten und speichern.'}
 function setAdminPane(name){if(name==='exercises')exerciseSavedOnly=false;document.querySelectorAll('.admin-tabs button').forEach(b=>b.classList.toggle('on',b.dataset.pane===name));document.querySelectorAll('.admin-pane').forEach(p=>p.classList.toggle('active',p.id==='pane-'+name));if(name==='vocab')renderAdminLists()}
 // Family sync v0.5: explicit publishing by parent, read-only content for child.
 const SYNC_KEY='sprachkompass-family-sync-v1';
 let familySync=(()=>{try{return JSON.parse(localStorage.getItem(SYNC_KEY))||{}}catch{return {}}})();
 let syncBusy=false, syncPoll=null, progressDebounce=null;
 const syncRole=()=>''; // v0.6 offline-only, legacy server links ignored
 function saveSync(){try{localStorage.setItem(SYNC_KEY,JSON.stringify(familySync))}catch{toast('Geräteverbindung konnte nicht gespeichert werden. Speicherplatz prüfen.')}renderSyncStatus()}
 function syncServer(value){let u;try{u=new URL((value||'').trim())}catch{throw Error('Bitte eine gültige Serveradresse mit https:// eingeben.')}const local=/^(localhost|127\.0\.0\.1|\[::1\])$/.test(u.hostname);if(u.protocol!=='https:'&&!(u.protocol==='http:'&&local))throw Error('Für Geräte-Synchronisierung ist HTTPS erforderlich.');if(u.username||u.password||u.search||u.hash)throw Error('Serveradresse ohne Zugangsdaten oder Zusätze eingeben.');return u.origin}
 async function syncFetch(method,path,body={},token='',setup=''){
  const headers={'Content-Type':'application/json'};
  if(token)headers.Authorization='Bearer '+token;
  if(setup)headers['X-Sync-Setup']=setup;
  let response;
  try{response=await fetch((familySync.server||syncServer($('sync-child-server').value||$('sync-parent-server').value))+path,{method,headers,body:method==='GET'?undefined:JSON.stringify(body),cache:'no-store',credentials:'omit'})}
  catch{throw Error('Server nicht erreichbar. Bitte HTTPS-Adresse und Internet prüfen.')}
  let json;try{json=await response.json()}catch{throw Error('Server liefert keine gültige Antwort. API/Hosting prüfen.')}
  if(!response.ok){const err=Error(json.error||('Serverfehler '+response.status));err.status=response.status;throw err}
  return json;
 }
 function renderSyncStatus(){
  const role=syncRole();
  document.body.classList.toggle('child-connected',role==='child');
  $('sync-indicator').textContent=role==='child'?'Verbunden':role==='parent'?'Eltern-Sync':'Verbinden';
  $('sync-parent-setup').classList.toggle('hidden',role==='parent');
  $('sync-parent-connected').classList.toggle('hidden',role!=='parent');
  $('sync-child-setup').classList.toggle('hidden',role==='child');
  $('sync-child-connected').classList.toggle('hidden',role!=='child');
  let message=familySync.lastSync?'Letzter erfolgreicher Kontakt: '+new Date(familySync.lastSync).toLocaleString('de-DE'):'Noch kein erfolgreicher Abgleich';
  if(role==='child')$('sync-child-status').textContent=message+' · Lernmaterial bleibt auf diesem Gerät gespeichert.';
  if(role==='parent')$('sync-parent-status').textContent='Server: '+familySync.server+' · Freigabestand '+(familySync.revision||0)+' · '+message;
  if(role==='parent')$('sync-progress-summary').textContent=familySync.progressSummary||'Gemerkte Wörter des Kindgeräts erscheinen hier nach einem Abgleich.';
  $('sync-parent-server').value=familySync.server||$('sync-parent-server').value||location.origin;
  $('sync-child-server').value=familySync.server||$('sync-child-server').value||location.origin;
 }
 function openSyncDialog(){
  if(syncRole()==='parent'){show('admin');setAdminPane('sync');return}
  $('sync-dialog').classList.remove('hidden');renderSyncStatus();
 }
 function showSyncMessage(text){$('sync-dialog-message').textContent=text}
 async function syncCreate(){
  const button=$('sync-create'),setup=$('sync-parent-secret').value;
  if(syncRole())return toast('Dieses Gerät ist bereits verbunden.');
  if(setup.length<16)return toast('Bitte das mindestens 16-stellige Server-Einrichtungspasswort eingeben.');
  try{
   familySync.server=syncServer($('sync-parent-server').value);
   button.disabled=true;
   const created=await syncFetch('POST','/api/sync/create',{},'',setup);
   familySync={role:'parent',server:familySync.server,token:created.parentToken,familyId:created.familyId,revision:created.revision};
   saveSync();$('sync-parent-secret').value='';
   await syncPublish();
   toast('Familie angelegt und Lernmaterial freigegeben.');
  }catch(err){toast('Synchronisierung: '+err.message)}finally{button.disabled=false;renderSyncStatus()}
 }
 const publishCollection=()=>({vocab:data.vocab.map(({star,...x})=>x),notes:data.notes,exercises:data.exercises.map(({star,...x})=>x)});
 async function syncPublish(){
  if(syncRole()!=='parent')return;
  if(!navigator.onLine)return toast('Offline: Inhalte lokal gespeichert. Später freigeben.');
  const btn=$('sync-publish');btn.disabled=true;
  try{
   const result=await syncFetch('PUT','/api/sync/content',{revision:familySync.revision,content:publishCollection()},familySync.token);
   familySync.revision=result.revision;familySync.lastSync=now();saveSync();toast('Freigabe erfolgreich. Kindgerät erhält die Inhalte beim nächsten Abgleich.');
  }catch(err){toast('Freigabe fehlgeschlagen: '+err.message)}finally{btn.disabled=false}
 }
 async function syncInvite(){
  if(syncRole()!=='parent')return;
  const button=$('sync-invite');button.disabled=true;
  try{
   const result=await syncFetch('POST','/api/sync/invite',{},familySync.token);
   $('sync-pair-code').textContent=result.code;
   $('sync-parent-address').textContent='Serveradresse: '+familySync.server;
   $('sync-invite-result').classList.remove('hidden');
  }catch(err){toast('Kein Verbindungscode: '+err.message)}finally{button.disabled=false}
 }
 async function syncCheck(){
  if(syncRole()!=='parent')return;
  try{
   const state=await syncFetch('GET','/api/sync/content',{},familySync.token);
   const v=Object.values(state.progress?.vocab||{}).filter(Boolean).length;
   const e=Object.values(state.progress?.exercises||{}).filter(Boolean).length;
   familySync.progressSummary='Vom Kind gemerkt: '+v+' Vokabeln · '+e+' Übungen';
   familySync.lastSync=now();saveSync();
   if(state.revision!==familySync.revision)toast('Achtung: Cloud-Version '+state.revision+' unterscheidet sich vom lokalen Stand '+familySync.revision+'. Bitte nicht ungeprüft überschreiben.');
   else toast('Cloudstand geprüft.');
  }catch(err){toast('Prüfen fehlgeschlagen: '+err.message)}
 }
 async function syncRevoke(){
  if(syncRole()!=='parent'||!confirm('Alle verbundenen Kindgeräte sperren? Zum Wiederverbinden sind neue Codes erforderlich. Lokal heruntergeladene Inhalte bleiben auf den Kindgeräten erhalten.'))return;
  try{await syncFetch('POST','/api/sync/revoke-children',{},familySync.token);toast('Alle Kindgeräte serverseitig gesperrt.')}catch(err){toast(err.message)}
 }
 async function syncJoin(){
  const btn=$('sync-join');
  if(syncRole()==='parent')return;
  const code=$('sync-child-code').value.trim().toUpperCase();
  if(!/^[A-Z2-9]{5}-?[A-Z2-9]{5}$/.test(code))return showSyncMessage('Bitte den 10-stelligen Verbindungscode eingeben.');
  if(data.vocab.some(v=>!v.demo)||data.notes.some(n=>!n.demo)||data.exercises.some(e=>!e.demo)){
   if(!confirm('Das Kindgerät erhält die Lernsammlung des Elterngeräts. Eigene Inhalte auf diesem Gerät werden ersetzt. Vorher bei Bedarf eine Sicherung erstellen.'))return;
  }
  let server;try{server=syncServer($('sync-child-server').value)}catch(err){return showSyncMessage(err.message)}
  btn.disabled=true;
  try{
   const old=familySync;
   familySync={server};
   const result=await syncFetch('POST','/api/sync/join',{code});
   familySync={role:'child',server,token:result.childToken,revision:0,pending:{vocab:{},exercises:{}}};
   saveSync();$('sync-child-code').value='';
   await syncChildRefresh();
   showSyncMessage('Kindgerät verbunden. Neue Inhalte werden beim Öffnen der App aktualisiert.');
   toast('Kindgerät verbunden!');
  }catch(err){showSyncMessage(err.message)}finally{btn.disabled=false;renderSyncStatus()}
 }
 function queueProgress(kind,item){
  if(syncRole()!=='child')return;
  familySync.pending=familySync.pending||{vocab:{},exercises:{}};
  familySync.pending[kind]=familySync.pending[kind]||{};
  familySync.pending[kind][item.id]=!!item.star;
  saveSync();
  clearTimeout(progressDebounce);
  progressDebounce=setTimeout(()=>{if(navigator.onLine)syncChildRefresh()},1300);
 }
 async function syncChildRefresh(){
  if(syncRole()!=='child'||syncBusy||!navigator.onLine)return;
  syncBusy=true;
  try{
   let remote=await syncFetch('GET','/api/sync/content',{},familySync.token);
   const valid={vocab:new Set(remote.content.vocab.map(x=>x.id)),exercises:new Set(remote.content.exercises.map(x=>x.id))};
   const changes={vocab:{},exercises:{}};
   // Upload in bounded batches. Drop changes for content removed by the parent.
   let remaining=450;
   familySync.pending=familySync.pending||{vocab:{},exercises:{}};
   for(const kind of ['vocab','exercises']){
    familySync.pending[kind]=familySync.pending[kind]||{};
    for(const [id,value] of Object.entries(familySync.pending[kind])){
     if(!valid[kind].has(id)){delete familySync.pending[kind][id];continue}
     if(remaining>0){changes[kind][id]=!!value;remaining--}
    }
   }
   if(Object.keys(changes.vocab).length||Object.keys(changes.exercises).length){
    await syncFetch('PATCH','/api/sync/progress',{changes},familySync.token);
    for(const kind of ['vocab','exercises'])for(const id of Object.keys(changes[kind]))delete familySync.pending[kind][id];
    saveSync();
    remote=await syncFetch('GET','/api/sync/content',{},familySync.token);
   }
   const latestContent=remote.content;
   if(!latestContent||!['vocab','notes','exercises'].every(k=>Array.isArray(latestContent[k])))throw Error('Cloud-Daten sind beschädigt.');
   const oldMeta=data.meta;
   for(const kind of ['vocab','notes','exercises'])data[kind]=latestContent[kind];
   data.meta=oldMeta;
   for(const kind of ['vocab','exercises']){
    const remoteFlags=remote.progress?.[kind]||{};
    for(const item of data[kind])item.star=Object.prototype.hasOwnProperty.call(familySync.pending[kind]||{},item.id)?
        !!familySync.pending[kind][item.id]:!!remoteFlags[item.id];
   }
   familySync.revision=remote.revision;
   familySync.lastSync=now();
   persist();saveSync();renderScopeView();
   if(current==='saved')renderSaved();
   if(current==='admin')show('home');
   return true;
  }catch(err){
   showSyncMessage('Sync fehlgeschlagen: '+err.message);
   if(err.status===401)toast('Der Elternzugang für dieses Gerät wurde gesperrt. Bereits geladene Inhalte bleiben offline verfügbar.');
   return false;
  }finally{
   syncBusy=false;renderSyncStatus();
   if(syncRole()==='child'&&navigator.onLine&&
      ['vocab','exercises'].some(kind=>Object.keys(familySync.pending?.[kind]||{}).length))
      setTimeout(syncChildRefresh,300);
  }
 }
 function wireSync(){
  $('sync-open').addEventListener('click',openSyncDialog);
  $('sync-close').addEventListener('click',()=>$('sync-dialog').classList.add('hidden'));
  $('sync-create').addEventListener('click',syncCreate);
  $('sync-publish').addEventListener('click',syncPublish);
  $('sync-invite').addEventListener('click',syncInvite);
  $('sync-check').addEventListener('click',syncCheck);
  $('sync-revoke').addEventListener('click',syncRevoke);
  $('sync-join').addEventListener('click',syncJoin);
  $('sync-now').addEventListener('click',async()=>{if(await syncChildRefresh())toast('Lerninhalte sind aktuell.');else toast('Kein Abgleich möglich, Offline-Inhalte bleiben erhalten.');});
  $('sync-child-disconnect').addEventListener('click',()=>{
   if(!confirm('Verbindung auf diesem Gerät trennen? Bereits geladene Lerninhalte bleiben vorhanden.'))return;
   familySync={};saveSync();showSyncMessage('Verbindung auf diesem Gerät getrennt.');toast('Geräteverbindung getrennt.');
  });
  window.addEventListener('online',()=>{if(syncRole()==='child')syncChildRefresh()});
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&syncRole()==='child')syncChildRefresh()});
  syncPoll=setInterval(()=>{if(!document.hidden&&syncRole()==='child'&&navigator.onLine)syncChildRefresh()},60000);
  renderSyncStatus();
  if(syncRole()==='child'&&navigator.onLine)syncChildRefresh();
 }

 function wire(){document.body.addEventListener('click',async event=>{const go=event.target.closest('[data-go]');if(go){if(go.dataset.go==='cards')cardSavedOnly=false;if(go.dataset.go==='exercises'){exerciseSavedOnly=false;exercisePage=0}show(go.dataset.go);return}const pageButton=event.target.closest('[data-page]');if(pageButton){const [name,stepText]=pageButton.dataset.page.split(':');const step=Number(stepText);if(name==='saved'){savedPage+=step;renderSaved()}if(name==='notes'){notePage+=step;renderNotes()}if(name==='exercises'){exercisePage+=step;renderExercises()}return}
  const language=event.target.closest('[data-select-language]');if(language){chooseLanguage(language.dataset.selectLanguage);return}
  const mark=event.target.closest('[data-mark-ex],[data-unmark-ex]');if(mark){const id=mark.dataset.markEx||mark.dataset.unmarkEx;const ex=data.exercises.find(e=>e.id===id);if(ex){ex.star=mark.hasAttribute('data-unmark-ex')?false:!ex.star;queueProgress('exercises',ex);persist();if(current==='saved')renderSaved();else if(current==='exercises'&&exerciseSavedOnly&&!ex.star)renderExercises();else{const b=document.querySelector('[data-mark-ex]');if(b&&b.dataset.markEx===ex.id){b.textContent=ex.star?'⭐ Gemerkt':'☆ Merken';b.classList.toggle('is-saved',!!ex.star);b.setAttribute('aria-pressed',String(!!ex.star))}}toast(ex.star?'Übung in Merkliste gespeichert ⭐':'Übung aus Merkliste entfernt')}return}
  const openEx=event.target.closest('[data-open-ex]');if(openEx){exerciseSavedOnly=true;exercisePage=Math.max(0,visibleExercises().findIndex(e=>e.id===openEx.dataset.openEx));show('exercises');return}
  const onePdf=event.target.closest('[data-pdfone]');if(onePdf){exportExercisesPdf(false,[onePdf.dataset.pdfone]);return}
  const star=event.target.closest('[data-unstar]');if(star){const v=data.vocab.find(v=>v.id===star.dataset.unstar);if(v){v.star=false;queueProgress('vocab',v);persist();renderSaved()}return}const pn=event.target.closest('[data-printnote]');if(pn){printNotes([pn.dataset.printnote]);return}const listen=event.target.closest('[data-listen],[data-listen-slow]');if(listen){const id=listen.dataset.listen||listen.dataset.listenSlow;const ex=data.exercises.find(x=>x.id===id);if(ex)speakText(ex.spokenText,ex.language,!!listen.dataset.listenSlow);return}const check=event.target.closest('[data-check]');if(check){checkExercise(check.dataset.check);return}const del=event.target.closest('[data-delete]');if(del){const [group,id]=del.dataset.delete.split(':');const a=data[group];if(a&&confirm('Diesen Eintrag wirklich löschen?')){data[group]=a.filter(v=>v.id!==id);persist();renderAdminLists()}return}const ed=event.target.closest('[data-editvoc]');if(ed)return editVocab(ed.dataset.editvoc);const en=event.target.closest('[data-editnote]');if(en)return editNote(en.dataset.editnote);const ee=event.target.closest('[data-editexercise]');if(ee)return editExercise(ee.dataset.editexercise);
  const pane=event.target.closest('[data-pane]');if(pane)return setAdminPane(pane.dataset.pane);
  if(event.target.id==='ai-approve')return approveAI();if(event.target.id==='ai-cancel'){aiDraft=null;$('ai-review').classList.add('hidden');return}
 });
  $('admin-open').addEventListener('click',()=>show('admin'));$('admin-lock').addEventListener('click',()=>{adminUnlocked=false;renderAdmin();toast('Elternbereich gesperrt')});
  $('card-speak').addEventListener('click',()=>{const v=cardSubset[cardIdx];if(v)speakText(v.source,v.language)});$('flashcard').addEventListener('click',()=>{if(!cardSubset.length)return;cardFlipped=!cardFlipped;renderCard()});
  $('card-next').addEventListener('click',()=>moveCard(1));$('card-prev').addEventListener('click',()=>moveCard(-1));$('card-remember').addEventListener('click',()=>judgeCard(true));$('card-know').addEventListener('click',()=>judgeCard(false));$('card-shuffle').addEventListener('click',()=>{for(let i=cardSubset.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[cardSubset[i],cardSubset[j]]=[cardSubset[j],cardSubset[i]]}cardIdx=0;cardFlipped=false;renderCard();toast('Reihenfolge gemischt')});
  $('dir-foreign').addEventListener('click',()=>{cardDir='toDe';renderCards()});$('dir-german').addEventListener('click',()=>{cardDir='toForeign';renderCards()});
  $('train-saved').addEventListener('click',()=>{cardSavedOnly=true;cardIdx=0;show('cards')});
  $('train-saved-exercises').addEventListener('click',()=>{exerciseSavedOnly=true;exercisePage=0;show('exercises')});
  $('exercise-only-saved').addEventListener('click',()=>{exerciseSavedOnly=!exerciseSavedOnly;exercisePage=0;renderExercises()});
  $('pdf-exercises').addEventListener('click',()=>exportExercisesPdf(false));
  $('pdf-exercise-answers').addEventListener('click',()=>exportExercisesPdf(true));
  $('pdf-admin-exercises').addEventListener('click',()=>exportExercisesPdf(false));
  $('pdf-admin-answers').addEventListener('click',()=>exportExercisesPdf(true));
  $('scope-unit').addEventListener('change',scopeChanged);$('scope-from').addEventListener('change',scopeChanged);$('scope-to').addEventListener('change',scopeChanged);
  $('scope-reset').addEventListener('click',()=>{scope.unit='';scope.from='';scope.to='';savedPage=notePage=exercisePage=cardIdx=0;data.meta.studyScope=scope;persist();renderScopeView()});
  $('reset-language').addEventListener('click',()=>{if(!confirm('Eine andere Schulbuchsprache wählen? Bisherige Daten bleiben erhalten.'))return;adminUnlocked=false;show('home');$('language-setup').classList.add('setup-visible')});
  $('admin-gate').addEventListener('submit',async e=>{e.preventDefault();const form=e.target,pin=form.elements.pin.value;if(!/^\d{4,8}$/.test(pin)){toast('PIN muss 4–8 Ziffern haben');return}if(form.id==='pin-setup'){await setPin(pin);adminUnlocked=true;renderAdmin();toast('Eltern-PIN eingerichtet')}if(form.id==='pin-unlock'){if(await pinDigest(pin,data.meta.pinSalt)===data.meta.pinHash){adminUnlocked=true;renderAdmin()}else toast('PIN ist nicht richtig')}});
  $('pin-change').addEventListener('submit',async e=>{e.preventDefault();const pin=e.target.elements.pin.value;if(!/^\d{4,8}$/.test(pin))return toast('PIN muss 4–8 Ziffern haben');await setPin(pin);e.target.reset();toast('Neue PIN gespeichert')});
  $('vocab-form').addEventListener('submit',e=>{e.preventDefault();const result=addVocab(formObj(e.target));if(result==='added'){persist();e.target.elements.source.value='';e.target.elements.target.value='';e.target.elements.example.value='';renderAdminLists();toast('Vokabel gespeichert')}else toast(result==='duplicate'?'Vokabel bereits vorhanden':'Bitte beide Wörter eingeben')});
  $('note-form').addEventListener('submit',e=>{e.preventDefault();const form=formObj(e.target);form.examples=form.examples.split('\n').map(x=>x.trim()).filter(Boolean);if(addNote(form)){persist();e.target.reset();renderAdminLists();toast('Merkblatt gespeichert')}else toast('Titel und Erklärung erforderlich')});
  $('exercise-form').addEventListener('submit',e=>{e.preventDefault();if(addExercise(formObj(e.target))){persist();e.target.reset();renderAdminLists();toast('Übung gespeichert')}else toast('Frage, Lösungen und passende Dropdown-Optionen oder Hörtext prüfen')});
  $('vocab-search').addEventListener('input',renderAdminLists);
  $('ai-files').addEventListener('change',renderPreviews);$('ai-run').addEventListener('click',runAI);$('ai-demo').addEventListener('click',demoAI);$('print-notes').addEventListener('click',()=>printNotes(data.notes.filter(withinScope).map(n=>n.id)));$('editor-cancel').addEventListener('click',()=>{$('editor-dialog').close?.();$('editor-dialog').removeAttribute('open');editing=null});$('editor-form').addEventListener('submit',saveEditor);
  $('export-json').addEventListener('click',backup);$('export-csv').addEventListener('click',exportCsv);
  $('import-package').addEventListener('click',async()=>{
   const file=$('package-file').files[0];if(!file)return toast('Bitte lerninhalte.json auswählen');
   try{
    if(file.size>5*1024*1024)throw Error('Datei zu groß (maximal 5 MB)');
    const pack=JSON.parse(await file.text());
    if(!pack||typeof pack!=='object'||Array.isArray(pack)||!Array.isArray(pack.vocab)||!Array.isArray(pack.notes)||!Array.isArray(pack.exercises))throw Error('Erwartet werden die Arrays vocab, notes und exercises');
    if(pack.vocab.length+pack.notes.length+pack.exercises.length>5000)throw Error('Maximal 5000 Einträge je Paket');
    const incoming={vocab:[],notes:[],exercises:[]};const seen={vocab:new Set(),notes:new Set(),exercises:new Set()};
    const key=(kind,x)=>kind==='vocab'?JSON.stringify([norm(x.language),norm(x.unit),norm(x.source),norm(x.target),pageBounds(x)]):kind==='notes'?JSON.stringify([norm(x.language),norm(x.unit),norm(x.title),pageBounds(x)]):JSON.stringify([norm(x.language),norm(x.unit),norm(x.title),norm(x.question),pageBounds(x)]);
    const existing={};for(const kind of ['vocab','notes','exercises'])existing[kind]=new Set(data[kind].map(x=>key(kind,x)));
    let skipped=0;
    for(const kind of ['vocab','notes','exercises'])for(const raw of pack[kind]){
      if(!raw||typeof raw!=='object'||Array.isArray(raw))throw Error('Ungültiger Eintrag in '+kind);
      const x=clone(raw);x.language=String(x.language||'').trim();x.unit=String(x.unit||'Ohne Kapitel').trim();
      if(!LANGS.includes(x.language))throw Error('Unbekannte Sprache: '+x.language);
      if(!validPages(x))throw Error('Ungültiger Seitenbereich in '+kind);
      if(kind==='vocab'&&(!String(x.source||'').trim()||!String(x.target||'').trim()))throw Error('Vokabel ohne Wort oder Übersetzung');
      if(kind==='notes'&&(!String(x.title||'').trim()||!String(x.content||'').trim()))throw Error('Merkblatt ohne Titel oder Inhalt');
      if(kind==='exercises'){
        if(!String(x.question||'').trim()||!String(x.answer||'').trim())throw Error('Übung ohne Frage oder Antwort');
        if(!['dropdown','text','listening'].includes(x.type))throw Error('Unbekannter Übungstyp');
        if(x.type==='dropdown'&&(!Array.isArray(x.options)||x.options.length<2))throw Error('Dropdown ohne Auswahlmöglichkeiten');
        if(x.type==='listening'&&!String(x.spokenText||'').trim())throw Error('Hörübung ohne Hörtext');
      }
      const k=key(kind,x);if(existing[kind].has(k)||seen[kind].has(k)){skipped++;continue}seen[kind].add(k);
      x.id=uid();x.star=false;x.demo=false;x.createdAt=now();
      if(kind==='notes')x.examples=Array.isArray(x.examples)?x.examples.map(String):[];
      if(kind==='exercises'){x.options=Array.isArray(x.options)?x.options.map(String):[];x.answers=Array.isArray(x.answers)?x.answers.map(String):String(x.answer).split(';;').map(v=>v.trim())}
      incoming[kind].push(x);
    }
    const count=incoming.vocab.length+incoming.notes.length+incoming.exercises.length;
    if(!count){$('package-status').textContent='Keine neuen Inhalte · '+skipped+' Duplikate';return toast('Keine neuen Inhalte im Paket')}
    if(!confirm(`${incoming.vocab.length} Vokabeln, ${incoming.notes.length} Merkblätter, ${incoming.exercises.length} Übungen ergänzen? ${skipped} Duplikate werden übersprungen. Vorher wird ein Backup heruntergeladen.`))return;
    backup();
    for(const kind of ['vocab','notes','exercises'])data[kind].push(...incoming[kind]);
    if(!persist())return;
    renderAdminLists();renderScopeView();$('package-status').textContent=`${count} Inhalte ergänzt · ${skipped} Duplikate übersprungen`;
    toast('Lernpaket erfolgreich ergänzt');$('package-file').value='';
   }catch(err){$('package-status').textContent='Import nicht durchgeführt: '+err.message;toast('Importfehler: '+err.message)}
  });
  $('import-vocab').addEventListener('click',async()=>{const file=$('data-file').files[0];if(!file)return toast('Bitte eine CSV- oder JSON-Datei auswählen');try{const arr=extractImportedFile(await file.text(),file.name);let added=0,dupes=0;for(const v of arr){const result=addVocab(v);if(result==='added')added++;if(result==='duplicate')dupes++}persist();renderAdminLists();toast(`${added} Vokabeln importiert · ${dupes} Duplikate ausgelassen`)}catch(err){toast('Importfehler: '+err.message)}});
  $('restore-json').addEventListener('click',async()=>{const file=$('backup-file').files[0];if(!file)return toast('Bitte Sicherungsdatei auswählen');try{const parsed=JSON.parse(await file.text());if(!Array.isArray(parsed.vocab)||!Array.isArray(parsed.notes)||!Array.isArray(parsed.exercises))throw Error('Datei ist kein vollständiges SprachKompass-Backup');if(!confirm('Aktuelle Vokabeln, Merkblätter und Übungen durch diese Sicherung ersetzen?'))return;const pin=data.meta;data={vocab:parsed.vocab,notes:parsed.notes,exercises:parsed.exercises,meta:pin};scope.unit='';scope.from='';scope.to='';data.meta.studyScope=scope;persist();renderAdminLists();syncScope();toast('Sicherung wiederhergestellt')}catch(err){toast(err.message)}});
  $('delete-demo').addEventListener('click',()=>{if(!confirm('Alle Beispiel-Vokabeln, -Merkblätter und -Übungen löschen? Eigene Einträge bleiben erhalten.'))return;for(const k of ['vocab','notes','exercises'])data[k]=data[k].filter(v=>!v.demo);persist();renderAdminLists();toast('Beispieldaten gelöscht')});
  window.addEventListener('keydown',e=>{if(current!=='cards'||/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName))return;if(e.key==='ArrowRight')moveCard(1);if(e.key==='ArrowLeft')moveCard(-1);if(e.key===' '){e.preventDefault();if(cardSubset.length){cardFlipped=!cardFlipped;renderCard()}}});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&current==='admin'){adminUnlocked=false;renderAdmin()}});
 }
 wire();syncScope();renderHome();if(!activeLanguage())$('language-setup').classList.add('setup-visible');if(!storageOK)toast('Achtung: Der Browser kann Daten nicht dauerhaft speichern. Bitte Backup nutzen.');
 if('serviceWorker' in navigator&&location.protocol!=='file:')navigator.serviceWorker.register('./sw.js').catch(()=>{});
})();
