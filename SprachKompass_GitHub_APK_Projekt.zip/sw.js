const CACHE='sprachkompass-v5';
const SHELL=['./','./index.html','./app.js','./manifest.webmanifest','./icons/icon-192.png','./icons/icon-512.png'];
self.addEventListener('install',evt=>{evt.waitUntil(caches.open(CACHE).then(c=>c.addAll(SHELL)));self.skipWaiting()});
self.addEventListener('activate',evt=>{evt.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))));self.clients.claim()});
self.addEventListener('fetch',evt=>{const u=new URL(evt.request.url);if(evt.request.method!=='GET'||u.pathname.startsWith('/api/'))return;evt.respondWith(caches.match(evt.request).then(cached=>cached||fetch(evt.request)))})
