"""Private family synchronisation backend (stdlib only).

Parent can publish approved content; child can only read and set remembered flags.
Tokens are random bearer capabilities, hashed in SQLite. Never expose this DB
through static hosting. Put the service behind HTTPS before using across devices.
"""
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import threading
import time
from collections import defaultdict, deque
from contextlib import contextmanager, closing
from pathlib import Path

MAX_SYNC_BODY = 2_000_000
TOKENS = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'
ATTEMPTS = defaultdict(deque)
ATTEMPT_LOCK = threading.Lock()


def db_path():
    path = Path(os.environ.get('SYNC_DB_PATH', str(Path.home() / '.sprachkompass-family.sqlite3'))).expanduser().resolve()
    # Root for web content is parent of this module; DB and journals must not
    # be served from the document root at all.
    if path.parent == Path(__file__).resolve().parent:
        raise RuntimeError('SYNC_DB_PATH muss außerhalb des Webverzeichnisses liegen')
    return path


def connect():
    path = db_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    db = sqlite3.connect(str(path), timeout=15)
    db.row_factory = sqlite3.Row
    db.execute('PRAGMA busy_timeout=10000')
    db.execute('PRAGMA foreign_keys=ON')
    db.executescript('''
    CREATE TABLE IF NOT EXISTS family (
      id TEXT PRIMARY KEY, parent_hash TEXT UNIQUE NOT NULL, revision INTEGER NOT NULL DEFAULT 0,
      content TEXT NOT NULL DEFAULT '{"vocab":[],"notes":[],"exercises":[]}', updated INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS child (
      token_hash TEXT PRIMARY KEY, family_id TEXT NOT NULL REFERENCES family(id) ON DELETE CASCADE,
      created INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS invite (
      code_hash TEXT PRIMARY KEY, family_id TEXT NOT NULL REFERENCES family(id) ON DELETE CASCADE,
      expires INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS progress (
      family_id TEXT NOT NULL REFERENCES family(id) ON DELETE CASCADE,
      kind TEXT NOT NULL, content_id TEXT NOT NULL, starred INTEGER NOT NULL,
      PRIMARY KEY(family_id,kind,content_id)
    );
    ''')
    return db


@contextmanager
def database():
    with closing(connect()) as db:
        with db:
            yield db


def digest(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def random_token():
    return secrets.token_urlsafe(32)


def rate_limited(ip, route, limit=10, window=60):
    # Per-process defensive rate limit; reverse proxy needs its own limits for
    # deployments with multiple workers. Avoid untrusted X-Forwarded-For.
    key = (ip, route)
    with ATTEMPT_LOCK:
        q = ATTEMPTS[key]
        current = time.monotonic()
        while q and q[0] + window < current:
            q.popleft()
        if len(q) >= limit:
            return True
        q.append(current)
    return False


def parse_auth(headers):
    value = headers.get('Authorization', '')
    if not value.startswith('Bearer '):
        return ''
    token = value[7:].strip()
    return token if 32 <= len(token) <= 256 else ''


def member(db, token):
    if not token:
        return None
    hashed = digest(token)
    parent = db.execute('SELECT id FROM family WHERE parent_hash=?', (hashed,)).fetchone()
    if parent:
        return parent['id'], 'parent'
    child = db.execute('SELECT family_id FROM child WHERE token_hash=?', (hashed,)).fetchone()
    if child:
        return child['family_id'], 'child'
    return None


def check_collection(data):
    if not isinstance(data, dict) or set(data) != {'vocab', 'notes', 'exercises'}:
        raise ValueError('Sammlung muss Vokabeln, Merkblätter und Übungen enthalten')
    sizes = {'vocab': 9000, 'notes': 600, 'exercises': 2500}
    for kind, limit in sizes.items():
        arr = data[kind]
        if not isinstance(arr, list) or len(arr) > limit:
            raise ValueError('Zu viele Einträge in ' + kind)
        ids = set()
        for item in arr:
            if not isinstance(item, dict) or not isinstance(item.get('id'), str) or not 1 <= len(item['id']) <= 160:
                raise ValueError('Ungültige ID in ' + kind)
            if item['id'] in ids:
                raise ValueError('Doppelte ID in ' + kind)
            ids.add(item['id'])
            if any(k in item for k in ('pinHash', 'pinSalt', 'parentToken', 'syncToken', 'apiKey')):
                raise ValueError('Sensible Daten dürfen nicht in der Sammlung stehen')
    return data


def result(status, obj):
    return status, obj


def handle(method, path, headers, payload, ip):
    """Handle sync routes. Caller validates JSON and applies CORS/size limits."""
    if rate_limited(ip, 'pair' if path.endswith('/join') else path,
                    8 if path.endswith('/join') else 90, 60):
        return result(429, {'error': 'Zu viele Anfragen. Bitte später erneut versuchen.'})
    if path == '/api/sync/create' and method == 'POST':
        setup = os.environ.get('SYNC_SETUP_SECRET', '')
        if len(setup) < 16:
            return result(503, {'error': 'Synchronisierung ist auf dem Server nicht eingerichtet (SYNC_SETUP_SECRET fehlt).'})
        supplied = headers.get('X-Sync-Setup', '')
        if not hmac.compare_digest(supplied, setup):
            return result(403, {'error': 'Einrichtungspasswort ist falsch.'})
        fid = secrets.token_hex(10)
        parent_token = random_token()
        with database() as db:
            db.execute('INSERT INTO family(id,parent_hash,updated) VALUES(?,?,?)', (fid, digest(parent_token), int(time.time())))
        return result(201, {'familyId': fid, 'parentToken': parent_token, 'revision': 0})

    if path == '/api/sync/join' and method == 'POST':
        code = str(payload.get('code', '')).replace('-', '').strip().upper()
        if len(code) != 10 or any(c not in TOKENS for c in code):
            return result(400, {'error': 'Verbindungscode muss zehn Zeichen haben.'})
        with database() as db:
            db.execute('BEGIN IMMEDIATE')
            invite = db.execute('SELECT family_id,expires FROM invite WHERE code_hash=?', (digest(code),)).fetchone()
            if not invite or invite['expires'] < int(time.time()):
                return result(403, {'error': 'Verbindungscode ungültig oder abgelaufen.'})
            db.execute('DELETE FROM invite WHERE code_hash=?', (digest(code),))
            token = random_token()
            db.execute('INSERT INTO child(token_hash,family_id,created) VALUES(?,?,?)', (digest(token), invite['family_id'], int(time.time())))
        return result(200, {'childToken': token})

    token = parse_auth(headers)
    with database() as db:
        who = member(db, token)
        if not who:
            return result(401, {'error': 'Nicht verbunden oder Zugang wurde widerrufen.'})
        fid, role = who
        if path == '/api/sync/invite' and method == 'POST':
            if role != 'parent':
                return result(403, {'error': 'Nur Eltern dürfen Kindgeräte einladen.'})
            code = ''.join(secrets.choice(TOKENS) for _ in range(10))
            expires = int(time.time()) + 15 * 60
            db.execute('DELETE FROM invite WHERE family_id=?', (fid,))
            db.execute('INSERT INTO invite(code_hash,family_id,expires) VALUES(?,?,?)', (digest(code),fid,expires))
            return result(200, {'code': code[:5]+'-'+code[5:], 'expiresAt': expires})
        if path == '/api/sync/revoke-children' and method == 'POST':
            if role != 'parent':
                return result(403, {'error': 'Nur Eltern dürfen Geräte trennen.'})
            db.execute('DELETE FROM child WHERE family_id=?', (fid,))
            db.execute('DELETE FROM invite WHERE family_id=?', (fid,))
            return result(200, {'ok': True})
        if path == '/api/sync/content' and method == 'GET':
            family = db.execute('SELECT revision,content,updated FROM family WHERE id=?', (fid,)).fetchone()
            stars = {'vocab': {}, 'exercises': {}}
            for r in db.execute('SELECT kind,content_id,starred FROM progress WHERE family_id=?', (fid,)):
                if r['kind'] in stars:
                    stars[r['kind']][r['content_id']] = bool(r['starred'])
            return result(200, {'revision': family['revision'], 'content': json.loads(family['content']),
                                'updated': family['updated'], 'progress': stars})
        if path == '/api/sync/content' and method == 'PUT':
            if role != 'parent':
                return result(403, {'error': 'Kindgeräte dürfen Lernmaterial nicht verändern.'})
            if type(payload.get('revision')) is not int or payload['revision'] < 0:
                return result(400, {'error': 'Gültige Revisionsnummer erforderlich.'})
            try:
                content = check_collection(payload.get('content'))
            except ValueError as exc:
                return result(400, {'error': str(exc)})
            db.execute('BEGIN IMMEDIATE')
            found = db.execute('SELECT revision FROM family WHERE id=?', (fid,)).fetchone()
            if found['revision'] != payload['revision']:
                return result(409, {'error': 'Andere Version auf Server. Erst synchronisieren und Konflikt prüfen.', 'revision': found['revision']})
            rev = found['revision'] + 1
            db.execute('UPDATE family SET revision=?,content=?,updated=? WHERE id=?',
                       (rev, json.dumps(content, ensure_ascii=False, separators=(',', ':')), int(time.time()), fid))
            # Keep progress for retained item IDs only.
            for kind in ('vocab', 'exercises'):
                ids = {item['id'] for item in content[kind]}
                rows = db.execute('SELECT content_id FROM progress WHERE family_id=? AND kind=?', (fid,kind)).fetchall()
                for r in rows:
                    if r['content_id'] not in ids:
                        db.execute('DELETE FROM progress WHERE family_id=? AND kind=? AND content_id=?', (fid, kind, r['content_id']))
            return result(200, {'revision': rev, 'updated': int(time.time())})
        if path == '/api/sync/progress' and method == 'PATCH':
            if role != 'child':
                return result(403, {'error': 'Nur Kindgeräte dürfen ihren Lernfortschritt melden.'})
            changes = payload.get('changes', {})
            if not isinstance(changes, dict) or any(k not in ('vocab','exercises') for k in changes):
                return result(400, {'error': 'Nur Merkkennzeichnungen sind erlaubt.'})
            family = db.execute('SELECT content FROM family WHERE id=?', (fid,)).fetchone()
            content = json.loads(family['content'])
            valid = {kind: {x['id'] for x in content[kind]} for kind in ('vocab','exercises')}
            total = 0
            for kind, marks in changes.items():
                if not isinstance(marks, dict) or len(marks) > 500:
                    return result(400, {'error': 'Ungültige Merkliste.'})
                for id, value in marks.items():
                    if id not in valid[kind] or type(value) is not bool:
                        return result(400, {'error': 'Merkliste enthält unbekannte Einträge.'})
                    total += 1
            if total > 500:
                return result(400, {'error': 'Zu viele Änderungen.'})
            for kind, marks in changes.items():
                for id, value in marks.items():
                    db.execute('INSERT INTO progress(family_id,kind,content_id,starred) VALUES(?,?,?,?) '
                               'ON CONFLICT(family_id,kind,content_id) DO UPDATE SET starred=excluded.starred',
                               (fid,kind,id,1 if value else 0))
            return result(200, {'ok': True, 'updated': total})
    return result(404, {'error': 'Unbekannter Synchronisationspfad'})
